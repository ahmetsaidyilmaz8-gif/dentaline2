<template>
  <div class="flex flex-col gap-8">
    
    <!-- Üst Karşılama ve Hızlı Link Paneli -->
    <div class="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-teal-950 text-white rounded-3xl p-6 md:p-8 shadow-xl border border-slate-800">
      <!-- Arka Plan Parlamaları (Glows) -->
      <div class="absolute -top-24 -right-24 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div class="absolute -bottom-24 -left-24 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
      
      <div class="relative flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <!-- Sol Bölüm: Başlık ve İkon -->
        <div class="flex items-start md:items-center gap-4">
          <div class="p-3.5 bg-teal-500/10 text-teal-400 rounded-2xl border border-teal-500/20 shadow-inner shrink-0">
            <Icon name="heroicons:squares-2x2" class="w-8 h-8" />
          </div>
          <div>
            <h2 class="text-2xl md:text-3xl font-black tracking-tight bg-gradient-to-r from-white via-slate-100 to-teal-200 bg-clip-text text-transparent">Klinik Kontrol Paneli</h2>
            <p class="text-slate-400 text-sm font-medium mt-1">Poliklinik genel durumu ve bugünün hasta akışına hızlı bir bakış.</p>
          </div>
        </div>
        
        <!-- Sağ Bölüm: Hızlı Aksiyonlar ve Yenileme -->
        <div class="flex flex-wrap items-center gap-3">
          <NuxtLink 
            to="/patients"
            class="inline-flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-teal-600/20 active:scale-95 transition-all duration-200"
          >
            <Icon name="heroicons:user-plus" class="w-4 h-4" />
            <span>Hasta Listesi</span>
          </NuxtLink>
          <NuxtLink 
            to="/appointments"
            class="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white text-xs font-bold rounded-xl active:scale-95 transition-all duration-200"
          >
            <Icon name="heroicons:calendar-days" class="w-4 h-4" />
            <span>Randevu Ekle</span>
          </NuxtLink>
          <button
            @click="loadAll"
            class="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 text-slate-300 hover:text-white text-xs font-bold rounded-xl transition-all duration-200 active:scale-95 backdrop-blur-sm"
          >
            <Icon name="heroicons:arrow-path" class="w-4 h-4" :class="{ 'animate-spin': isLoading }" />
            <span>Yenile</span>
          </button>
        </div>
      </div>
    </div>


    <!-- Özet İstatistik Kartları -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      
      <!-- Toplam Hasta -->
      <div class="group relative bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-100 dark:border-slate-800 flex flex-col justify-between shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
        <div class="flex justify-between items-start">
          <div class="space-y-1">
            <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Toplam Hasta</span>
            <span class="text-4xl font-extrabold text-slate-800 dark:text-slate-100 leading-tight block font-mono">
              {{ stats?.totalPatients ?? 0 }}
            </span>
          </div>
          <div class="w-12 h-12 rounded-2xl bg-teal-50 dark:bg-teal-950/30 text-teal-600 dark:text-teal-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
            <Icon name="heroicons:users" class="w-6 h-6" />
          </div>
        </div>
        <div class="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
          <span class="text-teal-600 dark:text-teal-400 font-bold flex items-center gap-1">
            <Icon name="heroicons:arrow-trending-up" class="w-3.5 h-3.5" />
            <span>Bu ay +{{ stats?.newThisMonth ?? 0 }} yeni</span>
          </span>
          <span class="text-slate-400 dark:text-slate-500 font-medium">Kayıtlı Profil</span>
        </div>
      </div>

      <!-- Günlük Randevu -->
      <div class="group relative bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-100 dark:border-slate-800 flex flex-col justify-between shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
        <div class="flex justify-between items-start">
          <div class="space-y-1">
            <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Bugünkü Randevu</span>
            <span class="text-4xl font-extrabold text-slate-800 dark:text-slate-100 leading-tight block font-mono">
              {{ stats?.todayAppts ?? 0 }}
            </span>
          </div>
          <div class="w-12 h-12 rounded-2xl bg-sky-50 dark:bg-sky-950/30 text-sky-600 dark:text-sky-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
            <Icon name="heroicons:calendar" class="w-6 h-6" />
          </div>
        </div>
        <div class="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
          <span class="text-sky-600 dark:text-sky-400 font-bold flex items-center gap-1">
            <Icon name="heroicons:check-circle" class="w-3.5 h-3.5" />
            <span>Tamamlanan: {{ stats?.completedToday ?? 0 }}</span>
          </span>
          <span class="text-slate-400 dark:text-slate-500 font-medium">Bugün</span>
        </div>
      </div>

      <!-- Toplam Tahsilat -->
      <div class="group relative bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-100 dark:border-slate-800 flex flex-col justify-between shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
        <div class="flex justify-between items-start">
          <div class="space-y-1">
            <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Toplam Tahsilat</span>
            <span class="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 leading-tight block font-mono mt-1">
              {{ formatCurrency(stats?.totalRevenue ?? 0) }}
            </span>
          </div>
          <div class="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
            <Icon name="heroicons:banknotes" class="w-6 h-6" />
          </div>
        </div>
        <div class="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
          <span class="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
            <Icon name="heroicons:shield-check" class="w-3.5 h-3.5" />
            <span>Tahsil edilen bakiye</span>
          </span>
          <span class="text-slate-400 dark:text-slate-500 font-medium">Finans</span>
        </div>
      </div>

      <!-- Bekleyen Alacak -->
      <div class="group relative bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-100 dark:border-slate-800 flex flex-col justify-between shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
        <div class="flex justify-between items-start">
          <div class="space-y-1">
            <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Toplam Alacak</span>
            <span class="text-3xl font-extrabold text-rose-600 dark:text-rose-400 leading-tight block font-mono mt-1">
              {{ formatCurrency(stats?.totalDebt ?? 0) }}
            </span>
          </div>
          <div class="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
            <Icon name="heroicons:credit-card" class="w-6 h-6" />
          </div>
        </div>
        <div class="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
          <span class="text-rose-600 dark:text-rose-400 font-bold flex items-center gap-1">
            <Icon name="heroicons:exclamation-triangle" class="w-3.5 h-3.5" />
            <span>Kalan ödenmemiş</span>
          </span>
          <span class="text-slate-400 dark:text-slate-500 font-medium">Borç</span>
        </div>
      </div>

    </div>

    <!-- Bugünkü Randevular Tablosu -->
    <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-md overflow-hidden transition-all duration-300">
      <!-- Tablo Üst Alanı -->
      <div class="px-8 py-6 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-50/40 dark:bg-slate-950/20">
        <div class="flex items-center gap-3">
          <div class="p-2.5 bg-teal-500/10 text-teal-600 dark:text-teal-400 rounded-2xl border border-teal-500/10 dark:border-teal-900/30">
            <Icon name="heroicons:clock" class="w-5 h-5" />
          </div>
          <div>
            <h3 class="font-extrabold text-slate-800 dark:text-white text-lg">Bugün Yapılacak İşlemler & Randevular</h3>
            <p class="text-xs text-slate-400 dark:text-slate-500 mt-1 font-medium">Tarih: {{ formatDateLong(todayDate) }}</p>
          </div>
        </div>
        <span class="inline-flex items-center px-4 py-1.5 text-xs font-bold bg-sky-50 dark:bg-sky-950/20 text-sky-700 dark:text-sky-400 border border-sky-200/50 dark:border-sky-900/50 rounded-full shadow-sm">
          Toplam: {{ todayAppointments.length }}
        </span>
      </div>

      <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse text-sm">
          <thead>
            <tr class="bg-slate-50/30 dark:bg-slate-950/10 border-b border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-xs">
              <th class="px-8 py-4">Saat</th>
              <th class="px-8 py-4">Hasta Adı</th>
              <th class="px-8 py-4">İşlem / Tedavi</th>
              <th class="px-8 py-4">Alerjiler / Tıbbi Bilgi</th>
              <th class="px-8 py-4">Durum</th>
              <th class="px-8 py-4 text-right">Randevu İşlemi</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
            <!-- Boş Durum (Empty State) -->
            <tr v-if="todayAppointments.length === 0">
              <td colspan="6" class="px-8 py-20 text-center">
                <div class="flex flex-col items-center justify-center max-w-sm mx-auto">
                  <div class="w-16 h-16 rounded-3xl bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 flex items-center justify-center mb-4 border border-slate-200/50 dark:border-slate-700">
                    <Icon name="heroicons:calendar-days" class="w-8 h-8" />
                  </div>
                  <h4 class="font-bold text-slate-800 dark:text-white text-base">Planlanmış Randevu Yok</h4>
                  <p class="text-xs text-slate-400 dark:text-slate-500 mt-1 font-medium">Bugün için planlanmış bir randevu bulunmamaktadır.</p>
                </div>
              </td>
            </tr>
            <!-- Randevu Satırları -->
            <tr
              v-for="appt in todayAppointments"
              :key="appt._id"
              class="hover:bg-slate-50/40 dark:hover:bg-slate-800/30 transition-colors duration-150 group"
            >
              <!-- Saat -->
              <td class="px-8 py-5">
                <span class="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-100/80 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-mono font-bold text-xs shadow-inner">
                  <Icon name="heroicons:clock" class="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                  {{ appt.time }}
                </span>
              </td>
              <!-- Hasta Adı -->
              <td class="px-8 py-5">
                <div v-if="appt.patientId" class="flex flex-col">
                  <NuxtLink :to="`/patients/${appt.patientId._id}`" class="font-extrabold text-slate-800 dark:text-slate-200 hover:text-teal-600 dark:hover:text-teal-400 transition-colors block text-sm hover:underline underline-offset-2">
                    {{ appt.patientId.firstName }} {{ appt.patientId.lastName }}
                  </NuxtLink>
                  <span class="text-slate-400 dark:text-slate-500 text-xs font-semibold mt-1 flex items-center gap-1">
                    <Icon name="heroicons:phone" class="w-3.5 h-3.5 text-slate-300 dark:text-slate-600" />
                    {{ formatPhone(appt.patientId.phone) }}
                  </span>
                </div>
                <div v-else-if="appt.patientName" class="flex flex-col">
                  <span class="font-extrabold text-slate-800 dark:text-slate-200 text-sm flex items-center gap-1.5">
                    {{ appt.patientName }}
                    <span class="text-[10px] px-1.5 py-0.5 bg-amber-50 dark:bg-amber-950/30 text-amber-600 dark:text-amber-400 border border-amber-200/60 dark:border-amber-900/40 rounded font-bold">Manuel</span>
                  </span>
                  <span v-if="appt.patientPhone" class="text-slate-400 dark:text-slate-500 text-xs font-semibold mt-1 flex items-center gap-1">
                    <Icon name="heroicons:phone" class="w-3.5 h-3.5 text-slate-300 dark:text-slate-600" />
                    {{ formatPhone(appt.patientPhone) }}
                  </span>
                  <span v-else class="text-slate-400 dark:text-slate-500 text-xs font-medium mt-1">Kayıtsız Hasta</span>
                </div>
                <span v-else class="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 border border-rose-100 dark:border-rose-900/30 rounded-full">
                  <Icon name="heroicons:exclamation-circle" class="w-3.5 h-3.5" />
                  Kayıtsız Hasta
                </span>
              </td>
              <!-- İşlem / Tedavi -->
              <td class="px-8 py-5 font-semibold text-slate-600 dark:text-slate-300 text-sm">
                <span class="inline-flex items-center gap-2">
                  <span class="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                  {{ appt.procedure }}
                </span>
              </td>
              <!-- Alerjiler -->
              <td class="px-8 py-5">
                <span
                  v-if="appt.patientId?.allergies"
                  class="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 border border-rose-100/50 dark:border-rose-900/30 shadow-sm animate-pulse"
                  :title="appt.patientId.allergies"
                >
                  <Icon name="heroicons:exclamation-triangle" class="w-3.5 h-3.5" />
                  <span>Alerji: {{ appt.patientId.allergies }}</span>
                </span>
                <span v-else class="text-slate-300 dark:text-slate-700 text-xs font-medium block pl-3">—</span>
              </td>
              <!-- Durum -->
              <td class="px-8 py-5">
                <span
                  :class="[
                    getStatusInfo(appt.status).class,
                    'inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border shadow-sm'
                  ]"
                >
                  <span class="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span>
                  <span>{{ getStatusInfo(appt.status).label }}</span>
                </span>
              </td>
              <!-- İşlemler -->
              <td class="px-8 py-5 text-right">
                <div class="flex items-center justify-end gap-2">
                  <template v-if="appt.status === 'pending'">
                    <button
                      @click="updateStatus(appt._id, 'completed')"
                      class="p-2 bg-emerald-50 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 border border-emerald-200/50 dark:border-emerald-800/50 rounded-xl transition-all duration-200 hover:shadow-sm active:scale-95"
                      title="Tamamlandı olarak işaretle"
                    >
                      <Icon name="heroicons:check" class="w-4 h-4 stroke-[3]" />
                    </button>
                    <button
                      @click="updateStatus(appt._id, 'cancelled')"
                      class="p-2 bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 dark:hover:bg-rose-900/30 text-rose-600 dark:text-rose-400 border border-rose-200/50 dark:border-rose-800/50 rounded-xl transition-all duration-200 hover:shadow-sm active:scale-95"
                      title="İptal Et"
                    >
                      <Icon name="heroicons:x-mark" class="w-4 h-4 stroke-[3]" />
                    </button>
                  </template>
                  <span v-else class="inline-flex items-center gap-1 text-xs text-slate-400 dark:text-slate-500 font-semibold italic bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 rounded-xl px-2.5 py-1">
                    <Icon name="heroicons:lock-closed" class="w-3 h-3 text-slate-300 dark:text-slate-500" />
                    İşlem yapıldı
                  </span>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useUtils } from '~/composables/useUtils';

const { formatDateLong, formatPhone, formatCurrency, getStatusInfo } = useUtils();

const stats = ref(null);
const todayAppointments = ref([]);
const isLoading = ref(false);

const todayDate = new Date();

// İstatistikleri ve bugünün randevularını yükle
const loadStats = async () => {
  try {
    const data = await $fetch('/api/stats');
    stats.value = data;
  } catch (error) {
    console.error('İstatistik yükleme hatası:', error);
  }
};

const loadTodayAppointments = async () => {
  try {
    const todayStr = new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
    const data = await $fetch(`/api/appointments?date=${todayStr}`);
    todayAppointments.value = data;
  } catch (error) {
    console.error('Randevuları yükleme hatası:', error);
  }
};

const loadAll = async () => {
  isLoading.value = true;
  await Promise.all([loadStats(), loadTodayAppointments()]);
  isLoading.value = false;
};

// Randevu Durumu Güncelle
const updateStatus = async (apptId, status) => {
  try {
    await $fetch(`/api/appointments/${apptId}`, {
      method: 'PUT',
      body: { status }
    });
    
    // Listeyi ve İstatistikleri tazele
    await loadAll();
    
    // Global istatistikleri yenilemek için event fırlat
    window.dispatchEvent(new CustomEvent('refresh-stats'));
    
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: `Randevu durumu '${status === 'completed' ? 'Tamamlandı' : 'İptal Edildi'}' olarak güncellendi.`, type: 'success' }
    }));
  } catch (error) {
    console.error('Randevu güncellenemedi:', error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'İşlem sırasında bir hata oluştu.', type: 'error' }
    }));
  }
};



onMounted(() => {
  loadAll();
});
</script>
