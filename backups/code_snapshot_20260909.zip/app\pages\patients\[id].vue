<template>
  <div v-if="isLoading" class="flex flex-col items-center justify-center min-h-[400px]">
    <Icon name="heroicons:arrow-path" class="w-8 h-8 animate-spin text-teal-600 mb-2" />
    <span class="text-base text-slate-500 font-medium">Hasta profili yükleniyor...</span>
  </div>

  <div v-else-if="!patientData" class="text-center py-12">
    <span class="text-4xl">⚠️</span>
    <h3 class="text-slate-800 font-bold mt-2 text-lg">Hasta Bulunamadı</h3>
    <p class="text-slate-500 text-sm mt-1">Görüntülemek istediğiniz hasta kaydı silinmiş veya mevcut değil.</p>
    <NuxtLink to="/patients" class="mt-4 inline-flex px-4 py-2 bg-teal-600 text-white rounded-xl text-sm font-semibold">
      Hastalar Listesine Dön
    </NuxtLink>
  </div>

  <div v-else class="flex flex-col gap-6">
    <!-- Geri Butonu & Üst Başlık (Panel içinde) -->
    <div class="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex items-center gap-4">
      <NuxtLink
        to="/patients"
        class="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-sm flex items-center justify-center"
      >
        <Icon name="heroicons:arrow-left" class="w-4 h-4 text-slate-600 dark:text-slate-300" />
      </NuxtLink>
      <div>
        <span class="text-sm text-slate-400 dark:text-slate-500 font-semibold block uppercase tracking-wider">Hasta Detay Profili</span>
        <h2 class="text-2xl font-bold text-slate-800 dark:text-white tracking-tight">
          {{ patientData.patient.firstName }} {{ patientData.patient.lastName }}
        </h2>
      </div>
    </div>

    <!-- Hızlı Uyarı Panelleri (Alerji & Kronik Rahatsızlıklar) -->
    <div v-if="patientData.patient.allergies || patientData.patient.chronicDiseases" class="flex flex-col md:flex-row gap-3">
      <div v-if="patientData.patient.allergies" class="flex-1 bg-rose-50 dark:bg-rose-950/20 border border-rose-200/80 dark:border-rose-900/40 rounded-2xl p-4 flex gap-3">
        <span class="text-2xl shrink-0">🚨</span>
        <div>
          <h4 class="font-bold text-rose-800 dark:text-rose-400 text-sm uppercase tracking-wider">Tıbbi Alerji Uyarısı</h4>
          <p class="text-sm text-rose-700 dark:text-rose-300 font-semibold mt-1 leading-relaxed">{{ patientData.patient.allergies }}</p>
        </div>
      </div>
      <div v-if="patientData.patient.chronicDiseases" class="flex-1 bg-amber-50 dark:bg-amber-950/20 border border-amber-200/85 dark:border-amber-900/40 rounded-2xl p-4 flex gap-3">
        <span class="text-2xl shrink-0">⚠️</span>
        <div>
          <h4 class="font-bold text-amber-800 dark:text-amber-400 text-sm uppercase tracking-wider">Kronik Rahatsızlıklar</h4>
          <p class="text-sm text-amber-700 dark:text-amber-300 font-semibold mt-1 leading-relaxed">{{ patientData.patient.chronicDiseases }}</p>
        </div>
      </div>
    </div>

    <!-- İki Sütunlu Sayfa Düzeni -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
      
      <!-- SOL SÜTUN: Kart / Kişisel Bilgiler -->
      <div class="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm p-6 flex flex-col gap-6">
        <!-- Avatar ve Başlık -->
        <div class="flex flex-col items-center text-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-5">
          <div
            :class="[
              getAvatarColorClass(patientData.patient.firstName + ' ' + patientData.patient.lastName),
              'w-20 h-20 rounded-full flex items-center justify-center font-bold text-3xl tracking-widest shadow-md'
            ]"
          >
            {{ getInitials(patientData.patient.firstName, patientData.patient.lastName) }}
          </div>
          <div>
            <h3 class="font-bold text-slate-800 dark:text-white text-base">{{ patientData.patient.firstName }} {{ patientData.patient.lastName }}</h3>
            <span class="text-sm text-slate-400 dark:text-slate-500 font-medium font-mono block mt-0.5">TC: {{ patientData.patient.tcNo || 'Belirtilmemiş' }}</span>
          </div>
        </div>

        <!-- Demografik Detay Listesi -->
        <div class="space-y-4 text-sm">
          <!-- İletişim -->
          <div>
            <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">İletişim Bilgileri</span>
            <div class="mt-2 space-y-2 text-slate-600 dark:text-slate-300">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <Icon name="heroicons:phone" class="w-4 h-4 text-slate-400 dark:text-slate-500 shrink-0" />
                  <span class="font-bold font-mono">{{ formatPhone(patientData.patient.phone) }}</span>
                </div>
              </div>

              <!-- Hızlı Arama ve WhatsApp Eylem Butonları -->
              <div v-if="patientData.patient.phone" class="pt-1 pb-1 flex items-center gap-2">
                <!-- 1. Doğrudan Arama (tel:) -->
                <a
                  :href="getTelHref(patientData.patient.phone)"
                  class="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95 shadow-sky-600/20"
                  title="Hastanın numarasını doğrudan ara"
                >
                  <Icon name="heroicons:phone" class="w-3.5 h-3.5" />
                  <span>📞 Ara</span>
                </a>

                <!-- 2. WhatsApp Menü Butonu (Açılır Menü) -->
                <div class="relative flex-1" ref="whatsappDropdownRef">
                  <button
                    type="button"
                    @click="isWhatsAppMenuOpen = !isWhatsAppMenuOpen"
                    class="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95 shadow-emerald-600/20"
                    title="WhatsApp Hızlı Şablon Mesajları"
                  >
                    <Icon name="heroicons:chat-bubble-left-right" class="w-3.5 h-3.5" />
                    <span>WhatsApp Mesajı</span>
                    <Icon name="heroicons:chevron-down" class="w-3 h-3 opacity-80" />
                  </button>

                  <!-- WhatsApp Açılır Şablon Menüsü (Kategorili) -->
                  <div
                    v-if="isWhatsAppMenuOpen"
                    class="absolute left-0 sm:left-auto sm:right-0 mt-2 w-72 max-h-[460px] overflow-y-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl z-50 p-2 flex flex-col gap-2 text-xs"
                  >
                    <div
                      v-for="(group, gIdx) in whatsAppTemplateGroups"
                      :key="group.category"
                      :class="[gIdx > 0 ? 'pt-2 border-t border-slate-100 dark:border-slate-800' : '', 'space-y-1']"
                    >
                      <div class="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center gap-1.5">
                        <Icon :name="group.icon" class="w-3.5 h-3.5 text-slate-400" />
                        <span>{{ group.category }}</span>
                      </div>

                      <div class="space-y-0.5">
                        <button
                          v-for="item in group.items"
                          :key="item.id"
                          type="button"
                          @click="sendWhatsAppText(item.text)"
                          class="w-full text-left p-2 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 flex flex-col transition-colors group"
                        >
                          <div class="font-bold text-slate-800 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                            {{ item.label }}
                          </div>
                          <div class="text-[11px] text-slate-400 leading-tight mt-0.5">
                            {{ item.desc }}
                          </div>
                        </button>
                      </div>
                    </div>

                    <!-- Özel / Düzenleme Butonu -->
                    <div class="border-t border-slate-100 dark:border-slate-800 pt-1.5 mt-0.5">
                      <button
                        type="button"
                        @click="openCustomWhatsAppModal('appt_reminder')"
                        class="w-full text-left p-2 rounded-xl bg-emerald-50/60 hover:bg-emerald-50 dark:bg-emerald-950/20 dark:hover:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 font-bold flex items-center justify-between transition-colors border border-emerald-200/50 dark:border-emerald-800/50"
                      >
                        <span class="flex items-center gap-1.5">
                          <Icon name="heroicons:pencil-square" class="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                          <span>Mesajı Önizle / Özel Yaz</span>
                        </span>
                        <Icon name="heroicons:chevron-right" class="w-3.5 h-3.5 opacity-60" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="flex items-center gap-2">
                <Icon name="heroicons:envelope" class="w-4 h-4 text-slate-400 dark:text-slate-500 shrink-0" />
                <span class="truncate font-medium">{{ patientData.patient.email || 'E-posta tanımlanmamış' }}</span>
              </div>
              <div class="flex items-center gap-2">
                <Icon name="heroicons:map-pin" class="w-4 h-4 text-slate-400 dark:text-slate-500 shrink-0" />
                <span class="font-medium">{{ patientData.patient.address || 'Adres tanımlanmamış' }}</span>
              </div>
            </div>
          </div>

          <!-- Kimlik/Medikal -->
          <div class="border-t border-slate-100 dark:border-slate-800 pt-4">
            <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">Kişisel Bilgiler</span>
            <div class="mt-2 grid grid-cols-2 gap-x-4 gap-y-2 text-slate-600 dark:text-slate-300 font-medium">
              <div>
                <div class="text-xs text-slate-400 dark:text-slate-500">Yaş</div>
                <div class="mt-0.5">{{ calculateAge(patientData.patient.birthDate) ? `${calculateAge(patientData.patient.birthDate)} Yaş` : '—' }}</div>
              </div>
              <div>
                <div class="text-xs text-slate-400 dark:text-slate-500">Cinsiyet</div>
                <div class="mt-0.5">{{ patientData.patient.gender === 'male' ? 'Erkek' : patientData.patient.gender === 'female' ? 'Kadın' : 'Diğer' }}</div>
              </div>
              <div>
                <div class="text-xs text-slate-400 dark:text-slate-500">Kan Grubu</div>
                <div class="mt-0.5 text-teal-600 dark:text-teal-400 font-bold">{{ patientData.patient.bloodType || 'Bilinmiyor' }}</div>
              </div>
              <div>
                <div class="text-xs text-slate-400 dark:text-slate-500">Düzenli İlaçlar</div>
                <div class="mt-0.5">{{ patientData.patient.medications || 'Yok' }}</div>
              </div>
            </div>
          </div>

          <!-- Acil Durum Yakını -->
          <div class="border-t border-slate-100 dark:border-slate-800 pt-4">
            <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">Acil Durum İrtibatı</span>
            <div class="mt-2 text-slate-600 dark:text-slate-300 space-y-1.5 font-medium">
              <div class="text-slate-800 dark:text-slate-200 font-bold">{{ patientData.patient.emergencyContact || '—' }}</div>
              <div class="flex items-center gap-1.5 font-mono">
                <Icon name="heroicons:phone" class="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0" />
                <span>{{ formatPhone(patientData.patient.emergencyPhone) }}</span>
              </div>
            </div>
          </div>

          <!-- Notlar -->
          <div class="border-t border-slate-100 dark:border-slate-800 pt-4" v-if="patientData.patient.notes">
            <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">Hekim Notu</span>
            <p class="mt-1.5 p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200/50 dark:border-slate-800 rounded-xl text-slate-500 dark:text-slate-400 leading-relaxed">
              {{ patientData.patient.notes }}
            </p>
          </div>
        </div>
      </div>

      <!-- SAĞ SÜTUN: Sekmeli İçerik Alanı -->
      <div class="lg:col-span-2 flex flex-col gap-6">
        
        <!-- Sekme Düğmeleri -->
        <div class="bg-white dark:bg-slate-900 p-1.5 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm flex items-center gap-1">
          <button
            v-for="tab in tabs"
            :key="tab.value"
            @click="activeTab = tab.value"
            :class="[
              activeTab === tab.value
                ? 'bg-teal-600 text-white shadow-sm'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800',
              'flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all duration-200'
            ]"
          >
            <Icon :name="tab.icon" class="w-4 h-4" />
            <span>{{ tab.label }}</span>
          </button>
        </div>

        <!-- SEKME İÇERİKLERİ -->
        
        <!-- 1. TEDAVİLER & FİNANS SEKMESİ -->
        <div v-if="activeTab === 'treatments'" class="flex flex-col gap-6">
          
          <!-- Hızlı Finansal Bakiye Özeti -->
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div class="bg-white dark:bg-slate-900 p-4 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm">
              <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Toplam Borç</span>
              <span class="text-lg font-black text-slate-800 dark:text-slate-100 font-mono block mt-1">
                {{ formatCurrency(patientData.financials.totalFee) }}
              </span>
            </div>
            <div class="bg-white dark:bg-slate-900 p-4 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm">
              <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Toplam Ödenen</span>
              <span class="text-lg font-black text-emerald-600 dark:text-emerald-400 font-mono block mt-1">
                {{ formatCurrency(patientData.financials.totalPaid) }}
              </span>
            </div>
            <div
              :class="[
                patientData.financials.balance > 0 ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-100/50 dark:border-rose-900/30' : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800',
                'p-4 border rounded-2xl shadow-sm'
              ]"
            >
              <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Kalan Net Borç</span>
              <span
                :class="[
                  patientData.financials.balance > 0 ? 'text-rose-600' : 'text-slate-800 dark:text-slate-100',
                  'text-lg font-black font-mono block mt-1'
                ]"
              >
                {{ formatCurrency(patientData.financials.balance) }}
              </span>
            </div>
          </div>

          <!-- İşlem Butonları -->
          <div class="flex items-center gap-3">
            <button
              @click="openNewTreatmentModal"
              class="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-sm font-bold transition-all active:scale-95 shadow-sm"
            >
              <Icon name="heroicons:plus-circle" class="w-4 h-4" />
              <span>Yeni Tedavi Gir</span>
            </button>
            <button
              @click="openNewPaymentModal"
              class="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold transition-all active:scale-95 shadow-sm"
            >
              <Icon name="heroicons:currency-dollar" class="w-4 h-4" />
              <span>Ödeme Tahsil Et</span>
            </button>
          </div>

          <!-- Cari Hesap Defteri (Ledger) -->
          <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-950/20 border-b border-slate-100 dark:border-slate-800">
              <h4 class="font-bold text-slate-800 dark:text-white text-sm uppercase tracking-wider">Cari Hareket Kayıtları (Ledger)</h4>
            </div>

            <div class="overflow-x-auto">
              <table class="w-full text-left border-collapse text-sm">
                <thead>
                  <tr class="bg-slate-50 dark:bg-slate-950/10 border-b border-slate-100 dark:border-slate-800 text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider text-xs">
                    <th class="px-6 py-3.5">Tarih</th>
                    <th class="px-6 py-3.5">Tür</th>
                    <th class="px-6 py-3.5">İşlem Detayı / Açıklama</th>
                    <th class="px-6 py-3.5 text-right">Tutar</th>
                    <th class="px-6 py-3.5 text-right">Eylem</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                  <tr v-if="ledgerItems.length === 0">
                    <td colspan="5" class="px-6 py-10 text-center text-slate-400 dark:text-slate-500 font-medium text-sm">
                      Bu hastaya ait cari hareket kaydı bulunamadı.
                    </td>
                  </tr>
                  <tr
                    v-for="item in ledgerItems"
                    :key="item.key"
                    class="hover:bg-slate-50/30 dark:hover:bg-slate-800/20 transition-colors"
                  >
                    <!-- Tarih -->
                    <td class="px-6 py-4 font-mono font-semibold text-slate-600 dark:text-slate-300">
                      {{ formatDate(item.date) }}
                    </td>
                    <!-- Tür -->
                    <td class="px-6 py-4">
                      <span
                        v-if="item.type === 'treatment'"
                        class="px-2 py-0.5 rounded-full text-xs font-bold bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 border border-rose-100 dark:border-rose-900/30"
                      >
                        Tedavi Borcu
                      </span>
                      <span
                        v-else
                        class="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30"
                      >
                        Ödeme Girişi
                      </span>
                    </td>
                    <!-- Detay -->
                    <td class="px-6 py-4">
                      <div class="flex flex-col gap-0.5">
                        <span class="font-bold text-slate-700 dark:text-slate-200">{{ item.description }}</span>
                        <span v-if="item.tooth" class="text-xs font-bold text-teal-600 dark:text-teal-400 font-mono">Diş: {{ item.tooth }}</span>
                        <span v-if="item.notes" class="text-xs text-slate-400 dark:text-slate-500 font-medium">{{ item.notes }}</span>
                      </div>
                    </td>
                    <!-- Tutar -->
                    <td
                      :class="[
                        item.type === 'treatment' ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400',
                        'px-6 py-4 text-right font-black font-mono text-base'
                      ]"
                    >
                      {{ item.type === 'treatment' ? '-' : '+' }}{{ formatCurrency(item.amount) }}
                    </td>
                    <!-- Eylemler (Düzenleme & Silme) -->
                    <td class="px-6 py-4 text-right">
                      <div class="flex items-center justify-end gap-1">
                        <button
                          @click="openEditModal(item)"
                          class="p-1.5 text-slate-400 dark:text-slate-500 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                          title="İşlemi Düzenle"
                        >
                          <Icon name="heroicons:pencil-square" class="w-4 h-4" />
                        </button>
                        <button
                          @click="deleteLedgerItem(item)"
                          class="p-1.5 text-slate-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                          title="İşlemi Sil"
                        >
                          <Icon name="heroicons:trash" class="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

        </div>

        <!-- 2. RANDEVULAR SEKMESİ -->
        <div v-if="activeTab === 'appointments'" class="flex flex-col gap-4">
          <div class="flex items-center justify-between">
            <h3 class="font-bold text-slate-700 dark:text-slate-300 text-sm tracking-wider uppercase">Randevu Geçmişi ve Takvimi</h3>
            <button
              @click="isAppointmentModalOpen = true"
              class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-sm font-bold active:scale-95 transition-all shadow-sm"
            >
              <Icon name="heroicons:plus" class="w-3.5 h-3.5" />
              <span>Randevu Ekle</span>
            </button>
          </div>

          <div class="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
              <table class="w-full text-left border-collapse text-sm">
                <thead>
                  <tr class="bg-slate-50 dark:bg-slate-950/10 border-b border-slate-100 dark:border-slate-800 text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider text-xs">
                    <th class="px-6 py-3.5">Tarih / Saat</th>
                    <th class="px-6 py-3.5">Yapılacak İşlem</th>
                    <th class="px-6 py-3.5">Süre (Dk)</th>
                    <th class="px-6 py-3.5">Durum</th>
                    <th class="px-6 py-3.5">Notlar</th>
                    <th class="px-6 py-3.5 text-right">İşlemler</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                  <tr v-if="patientData.appointments.length === 0">
                    <td colspan="6" class="px-6 py-10 text-center text-slate-400 dark:text-slate-500 font-medium text-sm">
                      Kayıtlı randevu bulunamadı.
                    </td>
                  </tr>
                  <tr
                    v-for="appt in patientData.appointments"
                    :key="appt._id"
                    class="hover:bg-slate-50/30 dark:hover:bg-slate-800/20 transition-colors"
                  >
                    <td class="px-6 py-4">
                      <div class="flex flex-col">
                        <span class="font-bold text-slate-700 dark:text-slate-200">{{ formatDate(appt.date) }}</span>
                        <span class="text-xs text-slate-400 dark:text-slate-500 font-bold font-mono mt-0.5">{{ appt.time }}</span>
                      </div>
                    </td>
                    <td class="px-6 py-4 font-semibold text-slate-600 dark:text-slate-300 text-sm">
                      {{ appt.procedure }}
                    </td>
                    <td class="px-6 py-4 font-mono font-medium text-slate-600 dark:text-slate-400">
                      {{ appt.duration }} dk
                    </td>
                    <td class="px-6 py-4">
                      <span
                        :class="[
                          getStatusInfo(appt.status).class,
                          'inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold border'
                        ]"
                      >
                        {{ getStatusInfo(appt.status).label }}
                      </span>
                    </td>
                    <td class="px-6 py-4 text-slate-400 dark:text-slate-500 italic">
                      {{ appt.notes || '—' }}
                    </td>
                    <td class="px-6 py-4 text-right">
                      <div class="flex items-center justify-end gap-1">
                        <button
                          v-if="appt.status === 'pending'"
                          @click="updateAppointmentStatus(appt._id, 'completed')"
                          class="p-1 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 rounded border border-emerald-200/50 dark:border-emerald-800/50 transition-colors"
                          title="Tamamla"
                        >
                          <Icon name="heroicons:check" class="w-4 h-4" />
                        </button>
                        <button
                          v-if="appt.status === 'pending'"
                          @click="updateAppointmentStatus(appt._id, 'cancelled')"
                          class="p-1 bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900/30 rounded border border-rose-200/50 dark:border-rose-800/50 transition-colors"
                          title="İptal Et"
                        >
                          <Icon name="heroicons:x-mark" class="w-4 h-4" />
                        </button>
                        <button
                          @click="deleteAppointment(appt._id)"
                          class="p-1 text-slate-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors"
                          title="Randevuyu Sil"
                        >
                          <Icon name="heroicons:trash" class="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- 3. DİŞ HARİTASI SEKMESİ -->
        <div v-if="activeTab === 'dentalchart'">
          <InteractiveDentalChart
            :patientId="patientId"
            @saved="loadPatientDetails"
            @transferred="loadPatientDetails"
          />
        </div>

        <!-- 4. LABORATUVAR & PROTEZ SEKMESİ -->
        <div v-if="activeTab === 'labworks'" class="flex flex-col gap-6">
          <!-- İstatistik ve Eylem Çubuğu -->
          <div class="flex items-center justify-between gap-4 flex-wrap">
            <div class="flex items-center gap-2 flex-wrap text-xs">
              <button
                type="button"
                @click="labWorkFilter = 'all'"
                :class="[labWorkFilter === 'all' ? 'bg-slate-800 text-white dark:bg-slate-100 dark:text-slate-900 font-bold' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800', 'px-3 py-1.5 rounded-xl transition-all shadow-sm']"
              >
                Tümü ({{ labStats.total }})
              </button>
              <button
                type="button"
                @click="labWorkFilter = 'sent'"
                :class="[labWorkFilter === 'sent' ? 'bg-amber-600 text-white font-bold' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800', 'px-3 py-1.5 rounded-xl transition-all shadow-sm flex items-center gap-1.5']"
              >
                <span class="w-2 h-2 rounded-full bg-amber-500"></span>
                <span>Teknisyende ({{ labStats.sent }})</span>
              </button>
              <button
                type="button"
                @click="labWorkFilter = 'received'"
                :class="[labWorkFilter === 'received' ? 'bg-emerald-600 text-white font-bold' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800', 'px-3 py-1.5 rounded-xl transition-all shadow-sm flex items-center gap-1.5']"
              >
                <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>Kliniğe Ulaştı ({{ labStats.received }})</span>
              </button>
              <button
                type="button"
                @click="labWorkFilter = 'fitted'"
                :class="[labWorkFilter === 'fitted' ? 'bg-slate-600 text-white font-bold' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800', 'px-3 py-1.5 rounded-xl transition-all shadow-sm']"
              >
                Takıldı ({{ labStats.fitted }})
              </button>
            </div>

            <button
              type="button"
              @click="openNewLabWorkModal"
              class="inline-flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-sm font-bold shadow-sm shadow-teal-600/20 transition-all active:scale-95"
            >
              <Icon name="heroicons:plus-circle" class="w-4 h-4" />
              <span>Yeni Laboratuvar İşi Ekle</span>
            </button>
          </div>

          <!-- Laboratuvar Kartları Listesi -->
          <div v-if="filteredLabWorks.length === 0" class="bg-white dark:bg-slate-900 p-12 text-center rounded-2xl border border-slate-100 dark:border-slate-800">
            <div class="w-12 h-12 rounded-2xl bg-teal-50 dark:bg-teal-950/40 text-teal-600 dark:text-teal-400 mx-auto flex items-center justify-center mb-3">
              <Icon name="heroicons:cube" class="w-6 h-6" />
            </div>
            <h4 class="font-bold text-slate-700 dark:text-slate-200 text-sm">Laboratuvar Kaydı Bulunamadı</h4>
            <p class="text-xs text-slate-400 dark:text-slate-500 mt-1 max-w-sm mx-auto">
              Bu hastaya ait teknisyene gönderilmiş veya tamamlanmış herhangi bir protez/laboratuvar işi henüz eklenmemiş.
            </p>
            <button
              type="button"
              @click="openNewLabWorkModal"
              class="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
            >
              <Icon name="heroicons:plus" class="w-3.5 h-3.5" />
              <span>İlk Laboratuvar İşini Ekle</span>
            </button>
          </div>

          <div v-else class="grid grid-cols-1 gap-4">
            <LabWorkCard
              v-for="item in filteredLabWorks"
              :key="item._id"
              :labItem="item"
              :patientPhone="patientData?.patient?.phone"
              @status-change="handleLabWorkStatusChange"
              @delete="deleteLabWork"
            />
          </div>
        </div>

        <!-- 5. ONAM FORMLARI SEKMESİ -->
        <div v-if="activeTab === 'consents'" class="flex flex-col gap-6">
          <div class="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h4 class="font-bold text-slate-800 dark:text-white text-base">Dijital Aydınlatılmış Onam Formları</h4>
              <p class="text-xs text-slate-400 dark:text-slate-500 mt-0.5">
                Hastanın tablet veya telefondan parmak/kalemle imzaladığı yasal onam belgeleri arşivi
              </p>
            </div>

            <button
              type="button"
              @click="openConsentModal"
              class="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold shadow-sm shadow-emerald-600/20 transition-all active:scale-95"
            >
              <Icon name="heroicons:pencil-square" class="w-4 h-4" />
              <span>Yeni Onam Formu İmzalat</span>
            </button>
          </div>

          <!-- Onam Formları Listesi -->
          <div v-if="(!patientData?.consentForms || patientData.consentForms.length === 0)" class="bg-white dark:bg-slate-900 p-12 text-center rounded-2xl border border-slate-100 dark:border-slate-800">
            <div class="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center mb-3">
              <Icon name="heroicons:document-check" class="w-6 h-6" />
            </div>
            <h4 class="font-bold text-slate-700 dark:text-slate-200 text-sm">İmzalanmış Onam Formu Yok</h4>
            <p class="text-xs text-slate-400 dark:text-slate-500 mt-1 max-w-sm mx-auto">
              Hasta için henüz dijital ortamda imzalatılmış aydınlatılmış onam kaydı bulunmamaktadır.
            </p>
            <button
              type="button"
              @click="openConsentModal"
              class="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
            >
              <Icon name="heroicons:pencil-square" class="w-3.5 h-3.5" />
              <span>Hemen Onam İmzalat</span>
            </button>
          </div>

          <div v-else class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div
              v-for="form in patientData.consentForms"
              :key="form._id"
              class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-4"
            >
              <div>
                <div class="flex items-start justify-between gap-2">
                  <div>
                    <div class="flex items-center gap-2 flex-wrap">
                      <span class="text-[10px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400 block">
                        Aydınlatılmış Onam
                      </span>
                      <span
                        v-if="form.toothNumber"
                        class="text-[10px] font-bold px-2 py-0.5 rounded-md bg-teal-50 dark:bg-teal-950/50 text-teal-700 dark:text-teal-300 border border-teal-200/70 dark:border-teal-800"
                      >
                        🦷 Diş No: {{ form.toothNumber }}
                      </span>
                    </div>
                    <h5 class="font-bold text-slate-800 dark:text-slate-100 text-sm mt-0.5">
                      {{ form.formTitle }}
                    </h5>
                  </div>
                  <div class="flex items-center gap-1.5">
                    <!-- Önizleme / Yazdırma Butonu -->
                    <button
                      type="button"
                      @click="openConsentPreview(form)"
                      class="p-1.5 text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      title="Belgeyi Önizle ve Yazdır"
                    >
                      <Icon name="heroicons:eye" class="w-4 h-4" />
                    </button>

                    <!-- PDF İndir Butonu (Silme Butonunun Hemen Yanında) -->
                    <button
                      type="button"
                      @click="handleDownloadConsentPdf(form)"
                      :disabled="downloadingConsentPdfId === form._id"
                      class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 border border-rose-200/80 dark:border-rose-800/60 rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95 disabled:opacity-50"
                      title="Onam Formunu PDF Olarak İndir"
                    >
                      <Icon v-if="downloadingConsentPdfId === form._id" name="heroicons:arrow-path" class="w-3.5 h-3.5 animate-spin" />
                      <Icon v-else name="heroicons:arrow-down-tray" class="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                      <span>PDF İndir</span>
                    </button>

                    <!-- Silme Butonu -->
                    <button
                      type="button"
                      @click="deleteConsentForm(form._id)"
                      class="p-1.5 text-slate-400 hover:text-rose-500 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
                      title="Onam Formunu Sil"
                    >
                      <Icon name="heroicons:trash" class="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div
                  v-if="form.acceptanceSignatureBase64 || form.acceptanceText"
                  class="mt-2.5 px-3 py-2 rounded-xl bg-amber-50/80 dark:bg-amber-950/20 border border-amber-200/70 dark:border-amber-900/40 text-[11px] text-amber-900 dark:text-amber-300 flex items-center justify-between gap-2 flex-wrap"
                >
                  <div class="flex items-center gap-1.5">
                    <Icon name="heroicons:pencil-square" class="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                    <span><strong>Hasta El Yazısı Beyanı:</strong></span>
                    <span v-if="!form.acceptanceSignatureBase64">"{{ form.acceptanceText }}"</span>
                  </div>
                  <div
                    v-if="form.acceptanceSignatureBase64"
                    class="border border-amber-300/80 dark:border-amber-800 rounded-lg bg-white p-1 max-h-10 flex items-center justify-center shadow-2xs"
                  >
                    <img
                      :src="form.acceptanceSignatureBase64"
                      alt="Hasta El Yazısı"
                      class="max-h-8 w-auto object-contain"
                    />
                  </div>
                </div>

                <div class="mt-3 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800/60 text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-h-36 overflow-y-auto select-text whitespace-pre-line font-sans">
                  {{ form.contentSummary }}
                </div>
              </div>

              <!-- İmza Alanı ve Otomatik Zaman Damgası Önizleme -->
              <div class="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-end justify-between gap-3 flex-wrap">
                <!-- Hekim Bilgisi & İmzası -->
                <div class="space-y-1">
                  <div class="flex items-center gap-1.5">
                    <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">Hekim Onayı</span>
                    <span class="text-[9px] font-bold text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/40 px-1.5 py-0.2 rounded border border-teal-200/60">✓ Dt</span>
                  </div>
                  <span class="text-xs font-bold text-slate-800 dark:text-slate-100 block">
                    {{ form.doctorName || 'Dt. M. Selman' }}
                  </span>
                  <div
                    v-if="form.doctorSignatureBase64"
                    class="border border-slate-200 dark:border-slate-700 rounded-lg bg-white p-1 shadow-2xs max-w-[120px] max-h-12 flex items-center justify-center"
                  >
                    <img
                      :src="form.doctorSignatureBase64"
                      alt="Hekim İmzası"
                      class="max-h-9 w-auto object-contain"
                    />
                  </div>
                  <span v-else class="text-[10px] text-slate-400 block italic">Hekim Kaşe / İmza</span>
                </div>

                <!-- Hasta / Vasi Bilgisi & İmzası -->
                <div class="flex flex-col items-end gap-1">
                  <div class="text-right">
                    <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">Hasta / Vasi İmzası</span>
                    <span class="text-xs font-bold text-slate-800 dark:text-slate-100 block mt-0.5">
                      {{ form.signerName || form.patientName }}
                    </span>
                  </div>
                  <div class="border border-slate-200 dark:border-slate-700 rounded-xl bg-white p-1.5 shadow-sm min-w-[130px] max-w-[150px] max-h-14 flex items-center justify-center">
                    <img
                      :src="form.signatureBase64"
                      alt="Hasta İmzası"
                      class="max-h-10 w-auto object-contain"
                    />
                  </div>
                  <span class="text-[10px] font-mono text-slate-500 dark:text-slate-400 font-medium">
                    {{ form.signedAtFormatted || formatDateTime(form.signedAt) }}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- MODALLAR -->

    <!-- A. Tedavi Modalı (Yeni / Düzenle) -->
    <AppModal
      :isOpen="isTreatmentModalOpen"
      :title="editingTreatmentId ? '✏️ Tedavi İşlemini Düzenle' : '🦷 Tedavi / İşlem Giriş Formu'"
      width="md"
      @close="isTreatmentModalOpen = false"
    >
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Yapılan İşlem <span class="text-rose-500">*</span></label>
          <input
            v-model="treatmentForm.procedure"
            type="text"
            list="procedure-suggestions"
            required
            placeholder="İşlem adı yazın veya listeden seçin..."
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          />
          <datalist id="procedure-suggestions">
            <option v-for="proc in PROCEDURES" :key="proc" :value="proc" />
          </datalist>
        </div>
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Diş Numarası</label>
            <input
              v-model="treatmentForm.tooth"
              type="text"
              placeholder="Örn: 36, 18"
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Tedavi Ücreti (TL) <span class="text-rose-500">*</span></label>
            <input
              v-model.number="treatmentForm.fee"
              type="number"
              min="0"
              required
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
        </div>
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Tarih <span class="text-rose-500">*</span></label>
          <input
            v-model="treatmentForm.date"
            type="date"
            required
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          />
        </div>
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">İşlem Detay Notu</label>
          <textarea
            v-model="treatmentForm.notes"
            rows="2"
            placeholder="İşleme dair ek klinik detaylar..."
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          ></textarea>
        </div>
      </div>

      <template #footer>
        <button
          @click="isTreatmentModalOpen = false"
          class="px-4 py-2 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
        >
          İptal
        </button>
        <button
          @click="saveTreatment"
          :disabled="isSubmitting"
          class="px-4 py-2 bg-teal-600 hover:bg-teal-700 disabled:bg-teal-400 text-white rounded-xl text-sm font-bold shadow-sm transition-all"
        >
          {{ editingTreatmentId ? 'Değişiklikleri Kaydet' : 'Tedaviyi Ekle' }}
        </button>
      </template>
    </AppModal>

    <!-- B. Ödeme Tahsilatı Modalı (Yeni / Düzenle) -->
    <AppModal
      :isOpen="isPaymentModalOpen"
      :title="editingPaymentId ? '✏️ Ödeme Tahsilatını Düzenle' : '💵 Ödeme Tahsilat Formu'"
      width="md"
      @close="isPaymentModalOpen = false"
    >
      <div class="space-y-4">
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Miktar (TL) <span class="text-rose-500">*</span></label>
            <input
              v-model.number="paymentForm.amount"
              type="number"
              min="0.01"
              step="any"
              required
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Ödeme Yöntemi <span class="text-rose-500">*</span></label>
            <select
              v-model="paymentForm.method"
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            >
              <option v-for="m in PAYMENT_METHODS" :key="m.value" :value="m.value" class="bg-white dark:bg-slate-800 text-slate-800 dark:text-white">
                {{ m.icon }} {{ m.label }}
              </option>
            </select>
          </div>
        </div>
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Tarih <span class="text-rose-500">*</span></label>
          <input
            v-model="paymentForm.date"
            type="date"
            required
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          />
        </div>
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Açıklama Notu</label>
          <textarea
            v-model="paymentForm.notes"
            rows="2"
            placeholder="Dekont no veya elden tahsil edildi vb..."
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          ></textarea>
        </div>
      </div>

      <template #footer>
        <button
          @click="isPaymentModalOpen = false"
          class="px-4 py-2 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
        >
          İptal
        </button>
        <button
          @click="savePayment"
          :disabled="isSubmitting"
          class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-400 text-white rounded-xl text-sm font-bold shadow-sm transition-all"
        >
          {{ editingPaymentId ? 'Değişiklikleri Kaydet' : 'Ödemeyi Al' }}
        </button>
      </template>
    </AppModal>

    <!-- C. Yeni Randevu Modalı -->
    <AppModal
      :isOpen="isAppointmentModalOpen"
      title="📅 Randevu Oluşturma Formu"
      width="md"
      @close="isAppointmentModalOpen = false"
    >
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Planlanan İşlem <span class="text-rose-500">*</span></label>
          <select
            v-model="appointmentForm.procedure"
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          >
            <option value="" class="bg-white dark:bg-slate-800 text-slate-800 dark:text-white">Seçin</option>
            <option v-for="proc in PROCEDURES" :key="proc" :value="proc" class="bg-white dark:bg-slate-800 text-slate-800 dark:text-white">{{ proc }}</option>
          </select>
        </div>
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Tarih <span class="text-rose-500">*</span></label>
            <input
              v-model="appointmentForm.date"
              type="date"
              required
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Saat <span class="text-rose-500">*</span></label>
            <input
              v-model="appointmentForm.time"
              type="time"
              required
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
        </div>
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Süre (Dakika)</label>
          <select
            v-model.number="appointmentForm.duration"
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          >
            <option :value="15" class="bg-white dark:bg-slate-800 text-slate-800 dark:text-white">15 dakika (Hızlı kontrol)</option>
            <option :value="30" class="bg-white dark:bg-slate-800 text-slate-800 dark:text-white">30 dakika (Normal seans)</option>
            <option :value="45" class="bg-white dark:bg-slate-800 text-slate-800 dark:text-white">45 dakika</option>
            <option :value="60" class="bg-white dark:bg-slate-800 text-slate-800 dark:text-white">60 dakika (Kanal, Protez vb.)</option>
            <option :value="90" class="bg-white dark:bg-slate-800 text-slate-800 dark:text-white">90 dakika (İmplant cerrahisi)</option>
          </select>
        </div>
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Randevu Notları</label>
          <textarea
            v-model="appointmentForm.notes"
            rows="2"
            placeholder="Şikayetler veya ön hazırlık bilgileri..."
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          ></textarea>
        </div>
      </div>

      <template #footer>
        <button
          @click="isAppointmentModalOpen = false"
          class="px-4 py-2 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
        >
          İptal
        </button>
        <button
          @click="addAppointment"
          :disabled="isSubmitting"
          class="px-4 py-2 bg-teal-600 hover:bg-teal-700 disabled:bg-teal-400 text-white rounded-xl text-sm font-bold shadow-sm transition-all"
        >
          Randevuyu Kaydet
        </button>
      </template>
    </AppModal>

    <!-- D. WhatsApp Önizleme ve Özel Mesaj Modalı -->
    <AppModal
      :isOpen="isCustomWhatsAppModalOpen"
      title="💬 WhatsApp Mesajı Hazırla & Gönder"
      width="md"
      @close="isCustomWhatsAppModalOpen = false"
    >
      <div class="space-y-4 text-sm">
        <!-- Alıcı Bilgisi -->
        <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl flex items-center justify-between border border-slate-100 dark:border-slate-700/60">
          <div>
            <div class="text-xs text-slate-400 uppercase font-bold tracking-wider">Alıcı Hasta</div>
            <div class="font-bold text-slate-800 dark:text-white mt-0.5">
              {{ patientData.patient.firstName }} {{ patientData.patient.lastName }}
            </div>
          </div>
          <div class="font-mono font-bold text-emerald-600 dark:text-emerald-400 text-xs">
            {{ formatPhone(patientData.patient.phone) }}
          </div>
        </div>

        <!-- Hızlı Şablon Seçimi (Kategorili) -->
        <div>
          <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Hazır Şablonlar</label>
          <div class="space-y-2">
            <div v-for="group in whatsAppTemplateGroups" :key="group.category">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                <Icon :name="group.icon" class="w-3 h-3" />
                <span>{{ group.category }}</span>
              </div>
              <div class="flex gap-1.5 flex-wrap">
                <button
                  v-for="item in group.items"
                  :key="item.id"
                  type="button"
                  @click="applyTemplateItem(item)"
                  :class="[
                    selectedTemplateId === item.id
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700',
                    'px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors'
                  ]"
                >
                  {{ item.label }}
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Mesaj Metni Alanı -->
        <div>
          <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
            WhatsApp Mesaj Metni <span class="text-rose-500">*</span>
          </label>
          <textarea
            v-model="customWhatsAppText"
            rows="5"
            placeholder="Mesajınızı yazın..."
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-emerald-500 dark:focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-sm leading-relaxed bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          ></textarea>
          <p class="text-[11px] text-slate-400 mt-1">
            "WhatsApp'ta Aç" butonuna basıldığında bu metin hastanın sohbet ekranına otomatik olarak yazılacaktır.
          </p>
        </div>
      </div>

      <template #footer>
        <button
          @click="isCustomWhatsAppModalOpen = false"
          class="px-4 py-2 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
        >
          İptal
        </button>
        <button
          @click="sendCustomWhatsApp"
          class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold shadow-sm transition-all inline-flex items-center gap-1.5 shadow-emerald-600/20"
        >
          <Icon name="heroicons:chat-bubble-left-right" class="w-4 h-4" />
          <span>WhatsApp'ta Aç ve Gönder</span>
        </button>
      </template>
    </AppModal>

    <!-- G. Laboratuvar & Protez İşi Modalı -->
    <AppModal
      :isOpen="isLabWorkModalOpen"
      title="🔬 Yeni Laboratuvar & Protez İşi Kaydı"
      width="md"
      @close="isLabWorkModalOpen = false"
    >
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
            Teknisyen / Laboratuvar Adı <span class="text-rose-500">*</span>
          </label>
          <input
            v-model="labWorkForm.labName"
            type="text"
            list="lab-suggestions"
            required
            placeholder="Örn: Kumluca Dental Lab"
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          />
          <datalist id="lab-suggestions">
            <option value="Kumluca Dental Lab" />
            <option value="Özlem Diş Protez Lab" />
            <option value="Merkez Dental Laboratuvarı" />
            <option value="Antalya Zirkon & Cad-Cam Lab" />
          </datalist>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
              İş Türü <span class="text-rose-500">*</span>
            </label>
            <input
              v-model="labWorkForm.workType"
              type="text"
              list="worktype-suggestions"
              required
              placeholder="Örn: Zirkonyum Kuron"
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
            <datalist id="worktype-suggestions">
              <option value="Zirkonyum Kuron" />
              <option value="E-Max Kuron / Lamina" />
              <option value="Metal Destekli Porselen" />
              <option value="Total Protez" />
              <option value="Bölümlü (İskelet) Protez" />
              <option value="Gece Plağı / Bruksizm" />
              <option value="İmplant Üstü Zirkonyum" />
              <option value="Geçici Kuron" />
            </datalist>
          </div>

          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
              Diş No (Virgülle)
            </label>
            <input
              v-model="labWorkForm.toothNumbers"
              type="text"
              placeholder="Örn: 11, 21, 22"
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white font-mono"
            />
          </div>
        </div>

        <div class="grid grid-cols-3 gap-3">
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
              Renk Kodu
            </label>
            <input
              v-model="labWorkForm.shadeColor"
              type="text"
              placeholder="A2, BL2..."
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white font-mono"
            />
          </div>

          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
              Gönderim Tarihi
            </label>
            <input
              v-model="labWorkForm.sentDate"
              type="date"
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>

          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
              Beklenen Teslim <span class="text-rose-500">*</span>
            </label>
            <input
              v-model="labWorkForm.expectedDate"
              type="date"
              required
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
        </div>

        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
            Lab Maliyeti (₺)
          </label>
          <input
            v-model.number="labWorkForm.price"
            type="number"
            min="0"
            step="50"
            placeholder="0"
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white font-mono"
          />
        </div>

        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
            Teknisyene Notlar
          </label>
          <textarea
            v-model="labWorkForm.notes"
            rows="2"
            placeholder="Basamak türü, oklüzyon, özel istekler..."
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white resize-none"
          ></textarea>
        </div>

        <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            @click="isLabWorkModalOpen = false"
            class="px-4 py-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl text-sm font-bold"
          >
            Vazgeç
          </button>
          <button
            type="button"
            :disabled="isSubmitting"
            @click="saveLabWork"
            class="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-sm font-bold shadow-sm"
          >
            Kaydet
          </button>
        </div>
      </div>
    </AppModal>

    <!-- H. Dijital Onam Formu ve İmza Modalı -->
    <ConsentSignatureModal
      :isOpen="isConsentModalOpen"
      :patientId="patientId"
      :patientName="patientData ? `${patientData.patient.firstName} ${patientData.patient.lastName}` : ''"
      @close="isConsentModalOpen = false"
      @saved="onConsentSaved"
    />

    <!-- I. Onam Formu Detaylı Önizleme ve PDF Modalı -->
    <ConsentPreviewModal
      :isOpen="isPreviewModalOpen"
      :form="selectedConsentForm"
      :patient="patientData ? patientData.patient : {}"
      @close="isPreviewModalOpen = false"
    />

  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { useRoute } from 'vue-router';
import { useUtils } from '~/composables/useUtils';
import { downloadConsentPdf } from '~/utils/consentPdf';

const route = useRoute();
const patientId = route.params.id;

// WhatsApp ve Hızlı Arama Durumları
const whatsappDropdownRef = ref(null);
const isWhatsAppMenuOpen = ref(false);
const isCustomWhatsAppModalOpen = ref(false);
const selectedTemplateId = ref('appt_reminder');
const customWhatsAppText = ref('');

const {
  formatDate,
  formatDateTime,
  calculateAge,
  formatCurrency,
  formatPhone,
  getAvatarColorClass,
  getInitials,
  PROCEDURES,
  PAYMENT_METHODS,
  getStatusInfo,
  todayStr
} = useUtils();

// Durumlar
const patientData = ref(null);
const isLoading = ref(true);
const isSubmitting = ref(false);

const tabs = [
  { value: 'treatments', label: 'Tedaviler & Finans', icon: 'heroicons:banknotes' },
  { value: 'appointments', label: 'Randevular', icon: 'heroicons:calendar' },
  { value: 'dentalchart', label: 'Diş Haritası', icon: 'heroicons:squares-plus' },
  { value: 'labworks', label: 'Laboratuvar & Protez', icon: 'heroicons:cube' },
  { value: 'consents', label: 'Onam Formları', icon: 'heroicons:document-check' }
];
const activeTab = ref('treatments');

// Laboratuvar & Protez Durumları
const isLabWorkModalOpen = ref(false);
const labWorkFilter = ref('all');
const labWorkForm = ref({
  labName: 'Kumluca Dental Lab',
  workType: 'Zirkonyum Kuron',
  toothNumbers: '',
  shadeColor: 'A2',
  sentDate: todayStr(),
  expectedDate: '',
  price: 0,
  notes: ''
});

const filteredLabWorks = computed(() => {
  const works = patientData.value?.labWorks || [];
  if (labWorkFilter.value === 'all') return works;
  return works.filter(w => w.status === labWorkFilter.value);
});

const labStats = computed(() => {
  const works = patientData.value?.labWorks || [];
  return {
    total: works.length,
    sent: works.filter(w => w.status === 'sent').length,
    received: works.filter(w => w.status === 'received').length,
    fitted: works.filter(w => w.status === 'fitted').length,
    revision: works.filter(w => w.status === 'revision').length,
  };
});

// Dijital Onam Formu Durumları
const isConsentModalOpen = ref(false);
const isPreviewModalOpen = ref(false);
const selectedConsentForm = ref(null);
const downloadingConsentPdfId = ref(null);

// Modal durumları
const isTreatmentModalOpen = ref(false);
const isPaymentModalOpen = ref(false);
const isAppointmentModalOpen = ref(false);
const editingTreatmentId = ref(null);
const editingPaymentId = ref(null);

// Form Nesneleri
const treatmentForm = ref({
  procedure: '',
  tooth: '',
  fee: 0,
  date: todayStr(),
  notes: ''
});

const paymentForm = ref({
  amount: 0,
  method: 'cash',
  date: todayStr(),
  notes: ''
});

const appointmentForm = ref({
  procedure: '',
  date: todayStr(),
  time: '09:00',
  duration: 30,
  notes: ''
});

// Hastaya ait verileri API'den yükle
const loadPatientDetails = async () => {
  try {
    isLoading.value = true;
    const data = await $fetch(`/api/patients/${patientId}`);
    patientData.value = data;
  } catch (error) {
    console.error('Hasta detayı yüklenemedi:', error);
  } finally {
    isLoading.value = false;
  }
};

// Tedaviler ve ödemeleri birleştirerek kronolojik "Cari Defter" girdileri oluşturur
const ledgerItems = computed(() => {
  if (!patientData.value) return [];
  
  const items = [];
  
  // Tedavileri borç olarak ekle
  patientData.value.treatments?.forEach((t) => {
    items.push({
      key: `t-${t._id}`,
      id: t._id,
      type: 'treatment',
      date: t.date,
      description: t.procedure,
      procedure: t.procedure,
      tooth: t.tooth,
      notes: t.notes,
      amount: t.fee,
      rawCreatedAt: t.createdAt
    });
  });

  // Ödemeleri alacak olarak ekle
  patientData.value.payments?.forEach((p) => {
    const methodLabel = PAYMENT_METHODS.find(m => m.value === p.method)?.label || p.method;
    items.push({
      key: `p-${p._id}`,
      id: p._id,
      type: 'payment',
      date: p.date,
      description: `Ödeme Tahsilatı (${methodLabel})`,
      method: p.method,
      notes: p.notes,
      amount: p.amount,
      rawCreatedAt: p.createdAt
    });
  });

  // Önce tarihe göre en yeni üstte, aynı tarihtekileri ise sisteme girilme sırasına göre sırala
  return items.sort((a, b) => {
    const dComp = b.date.localeCompare(a.date);
    if (dComp !== 0) return dComp;
    return new Date(b.rawCreatedAt).getTime() - new Date(a.rawCreatedAt).getTime();
  });
});

// Yeni Tedavi Modalı Aç
const openNewTreatmentModal = () => {
  editingTreatmentId.value = null;
  treatmentForm.value = {
    procedure: '',
    tooth: '',
    fee: 0,
    date: todayStr(),
    notes: ''
  };
  isTreatmentModalOpen.value = true;
};

// Yeni Ödeme Modalı Aç
const openNewPaymentModal = () => {
  editingPaymentId.value = null;
  paymentForm.value = {
    amount: 0,
    method: 'cash',
    date: todayStr(),
    notes: ''
  };
  isPaymentModalOpen.value = true;
};

// Cari Hareketi Düzenleme Modalı Aç
const openEditModal = (item) => {
  if (item.type === 'treatment') {
    editingTreatmentId.value = item.id;
    treatmentForm.value = {
      procedure: item.procedure || item.description || '',
      tooth: item.tooth || '',
      fee: item.amount || 0,
      date: item.date || todayStr(),
      notes: item.notes || ''
    };
    isTreatmentModalOpen.value = true;
  } else if (item.type === 'payment') {
    editingPaymentId.value = item.id;
    paymentForm.value = {
      amount: item.amount || 0,
      method: item.method || 'cash',
      date: item.date || todayStr(),
      notes: item.notes || ''
    };
    isPaymentModalOpen.value = true;
  }
};

// Tedavi Kaydet (Yeni veya Düzenle)
const saveTreatment = async () => {
  if (!treatmentForm.value.procedure || treatmentForm.value.fee === undefined || treatmentForm.value.fee === null) {
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Lütfen işlem adını ve ücretini girin.', type: 'error' }
    }));
    return;
  }
  try {
    isSubmitting.value = true;
    if (editingTreatmentId.value) {
      await $fetch(`/api/treatments/${editingTreatmentId.value}`, {
        method: 'PUT',
        body: {
          patientId,
          ...treatmentForm.value
        }
      });
      window.dispatchEvent(new CustomEvent('toast-message', {
        detail: { message: 'Tedavi işlemi başarıyla güncellendi.', type: 'success' }
      }));
    } else {
      await $fetch('/api/treatments', {
        method: 'POST',
        body: {
          patientId,
          ...treatmentForm.value
        }
      });
      window.dispatchEvent(new CustomEvent('toast-message', {
        detail: { message: 'Tedavi kaydı başarıyla eklendi.', type: 'success' }
      }));
    }

    isTreatmentModalOpen.value = false;
    treatmentForm.value = { procedure: '', tooth: '', fee: 0, date: todayStr(), notes: '' };
    editingTreatmentId.value = null;

    // Verileri ve üst bakiye özet kartlarını anlık olarak yenile
    await loadPatientDetails();
    window.dispatchEvent(new CustomEvent('refresh-stats'));
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: error?.data?.message || 'Tedavi kaydedilirken bir hata oluştu.', type: 'error' }
    }));
  } finally {
    isSubmitting.value = false;
  }
};

// Ödeme Kaydet (Yeni veya Düzenle)
const savePayment = async () => {
  if (!paymentForm.value.amount || !paymentForm.value.method) {
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Lütfen geçerli bir ödeme tutarı girin.', type: 'error' }
    }));
    return;
  }
  try {
    isSubmitting.value = true;
    if (editingPaymentId.value) {
      await $fetch(`/api/payments/${editingPaymentId.value}`, {
        method: 'PUT',
        body: {
          patientId,
          ...paymentForm.value
        }
      });
      window.dispatchEvent(new CustomEvent('toast-message', {
        detail: { message: 'Ödeme tahsilatı başarıyla güncellendi.', type: 'success' }
      }));
    } else {
      await $fetch('/api/payments', {
        method: 'POST',
        body: {
          patientId,
          ...paymentForm.value
        }
      });
      window.dispatchEvent(new CustomEvent('toast-message', {
        detail: { message: 'Ödeme başarıyla tahsil edildi.', type: 'success' }
      }));
    }

    isPaymentModalOpen.value = false;
    paymentForm.value = { amount: 0, method: 'cash', date: todayStr(), notes: '' };
    editingPaymentId.value = null;

    // Verileri ve üst bakiye özet kartlarını anlık olarak yenile
    await loadPatientDetails();
    window.dispatchEvent(new CustomEvent('refresh-stats'));
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: error?.data?.message || 'Ödeme kaydedilirken hata oluştu.', type: 'error' }
    }));
  } finally {
    isSubmitting.value = false;
  }
};

// Ledger (Cari) girdisini sil
const deleteLedgerItem = async (item) => {
  const confirmText = `${item.description} işlemini cari hesaptan silmek istediğinize emin misiniz?`;
  if (!window.confirm(confirmText)) return;

  try {
    const endpoint = item.type === 'treatment' ? `/api/treatments/${item.id}` : `/api/payments/${item.id}`;
    await $fetch(endpoint, { method: 'DELETE' });

    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Cari işlem başarıyla silindi.', type: 'success' }
    }));

    await loadPatientDetails();
    window.dispatchEvent(new CustomEvent('refresh-stats'));
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'İşlem silinirken bir hata oluştu.', type: 'error' }
    }));
  }
};

// Yeni Randevu Ekle
const addAppointment = async () => {
  if (!appointmentForm.value.procedure || !appointmentForm.value.date || !appointmentForm.value.time) {
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Lütfen randevu tarihi, saati ve işlem adını doldurun.', type: 'error' }
    }));
    return;
  }
  try {
    isSubmitting.value = true;
    await $fetch('/api/appointments', {
      method: 'POST',
      body: {
        patientId,
        ...appointmentForm.value
      }
    });

    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Randevu başarıyla kaydedildi.', type: 'success' }
    }));

    isAppointmentModalOpen.value = false;
    // Formu sıfırla
    appointmentForm.value = { procedure: '', date: todayStr(), time: '09:00', duration: 30, notes: '' };

    await loadPatientDetails();
    window.dispatchEvent(new CustomEvent('refresh-stats'));
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Randevu eklenirken hata oluştu.', type: 'error' }
    }));
  } finally {
    isSubmitting.value = false;
  }
};

// Randevu Durum Güncelle
const updateAppointmentStatus = async (apptId, status) => {
  try {
    await $fetch(`/api/appointments/${apptId}`, {
      method: 'PUT',
      body: { status }
    });

    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Randevu durumu güncellendi.', type: 'success' }
    }));

    await loadPatientDetails();
    window.dispatchEvent(new CustomEvent('refresh-stats'));
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Randevu güncellenirken hata oluştu.', type: 'error' }
    }));
  }
};

// Randevu Sil
const deleteAppointment = async (apptId) => {
  if (!window.confirm('Bu randevuyu silmek istediğinize emin misiniz?')) return;
  try {
    await $fetch(`/api/appointments/${apptId}`, {
      method: 'DELETE'
    });

    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Randevu kaydı silindi.', type: 'success' }
    }));

    await loadPatientDetails();
    window.dispatchEvent(new CustomEvent('refresh-stats'));
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Randevu silinirken hata oluştu.', type: 'error' }
    }));
  }
};

// Laboratuvar & Protez İşi Metodları
const openNewLabWorkModal = () => {
  const d = new Date();
  d.setDate(d.getDate() + 5);
  const fiveDaysLater = d.toISOString().split('T')[0];

  labWorkForm.value = {
    labName: 'Kumluca Dental Lab',
    workType: 'Zirkonyum Kuron',
    toothNumbers: '',
    shadeColor: 'A2',
    sentDate: todayStr(),
    expectedDate: fiveDaysLater,
    price: 0,
    notes: ''
  };
  isLabWorkModalOpen.value = true;
};

const saveLabWork = async () => {
  if (!labWorkForm.value.labName || !labWorkForm.value.workType || !labWorkForm.value.expectedDate) {
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Lütfen zorunlu alanları (Laboratuvar, İş Türü, Beklenen Tarih) doldurun.', type: 'error' }
    }));
    return;
  }

  try {
    isSubmitting.value = true;
    const teeth = labWorkForm.value.toothNumbers
      ? labWorkForm.value.toothNumbers.split(',').map(s => s.trim()).filter(Boolean)
      : [];

    await $fetch('/api/lab-works', {
      method: 'POST',
      body: {
        patientId,
        patientName: `${patientData.value.patient.firstName} ${patientData.value.patient.lastName}`,
        labName: labWorkForm.value.labName,
        workType: labWorkForm.value.workType,
        toothNumbers: teeth,
        shadeColor: labWorkForm.value.shadeColor,
        sentDate: labWorkForm.value.sentDate,
        expectedDate: labWorkForm.value.expectedDate,
        price: Number(labWorkForm.value.price) || 0,
        notes: labWorkForm.value.notes
      }
    });

    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Laboratuvar işi başarıyla kaydedildi.', type: 'success' }
    }));

    isLabWorkModalOpen.value = false;
    await loadPatientDetails();
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: error?.data?.message || 'Laboratuvar işi kaydedilemedi.', type: 'error' }
    }));
  } finally {
    isSubmitting.value = false;
  }
};

const handleLabWorkStatusChange = async ({ id, status }) => {
  try {
    await $fetch(`/api/lab-works/${id}`, {
      method: 'PUT',
      body: { status }
    });

    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Laboratuvar işi durumu güncellendi.', type: 'success' }
    }));

    await loadPatientDetails();
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Durum güncellenirken hata oluştu.', type: 'error' }
    }));
  }
};

const deleteLabWork = async (id) => {
  if (!confirm('Bu laboratuvar kaydını silmek istediğinizden emin misiniz?')) return;

  try {
    await $fetch(`/api/lab-works/${id}`, {
      method: 'DELETE'
    });

    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Laboratuvar kaydı silindi.', type: 'success' }
    }));

    await loadPatientDetails();
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Silme işlemi başarısız oldu.', type: 'error' }
    }));
  }
};

// Dijital Onam Formu Metodları
const openConsentModal = () => {
  isConsentModalOpen.value = true;
};

const openConsentPreview = (form) => {
  selectedConsentForm.value = form;
  isPreviewModalOpen.value = true;
};

const handleDownloadConsentPdf = async (form) => {
  downloadingConsentPdfId.value = form._id;
  try {
    await downloadConsentPdf(form, patientData.value?.patient || {});
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Aydınlatılmış Onam Formu PDF olarak başarıyla indirildi.', type: 'success' }
    }));
  } catch (error) {
    console.error('PDF indirme hatası:', error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'PDF oluşturulurken bir hata oluştu.', type: 'error' }
    }));
  } finally {
    downloadingConsentPdfId.value = null;
  }
};

const onConsentSaved = async () => {
  window.dispatchEvent(new CustomEvent('toast-message', {
    detail: { message: 'Aydınlatılmış onam formu ve dijital imza başarıyla arşivlendi.', type: 'success' }
  }));
  await loadPatientDetails();
};

const deleteConsentForm = async (id) => {
  if (!confirm('Bu imzalı onam formunu silmek istediğinizden emin misiniz?')) return;

  try {
    await $fetch(`/api/consent-forms/${id}`, {
      method: 'DELETE'
    });

    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Onam formu kaydı silindi.', type: 'success' }
    }));

    await loadPatientDetails();
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Onam formu silinemedi.', type: 'error' }
    }));
  }
};

// Telefon temizleme ve bağlantı yardımcıları
const cleanPhoneForWhatsApp = (phoneStr) => {
  if (!phoneStr) return '';
  let cleaned = phoneStr.replace(/\D/g, '');
  if (cleaned.startsWith('0')) cleaned = cleaned.substring(1);
  if (!cleaned.startsWith('90')) cleaned = '90' + cleaned;
  return cleaned;
};

const getTelHref = (phone) => {
  const digits = cleanPhoneForWhatsApp(phone);
  return digits ? `tel:${digits}` : '#';
};

const getWhatsAppUrl = (phone, message) => {
  const digits = cleanPhoneForWhatsApp(phone);
  const encodedText = encodeURIComponent(message || '');
  return `https://wa.me/${digits}?text=${encodedText}`;
};

// Dinamik WhatsApp Şablon Grupları
const clinicName = "Özel Kumluca Ağız ve Diş Sağlığı Polikliniği";
const clinicMapsUrl = "https://maps.app.goo.gl/Lo2V4zMTLkCBWe8o8?g_st=aw";

const whatsAppTemplateGroups = computed(() => {
  const patient = patientData.value?.patient;
  const fullName = patient ? `${patient.firstName} ${patient.lastName}` : 'Sayın Hastamız';
  const balance = patientData.value?.financials?.balance || 0;
  const nextAppt = patientData.value?.appointments?.find(a => a.status === 'pending');
  const apptDateStr = nextAppt ? formatDate(nextAppt.date) : 'yarın';
  const apptTimeStr = nextAppt?.time ? `saat ${nextAppt.time}` : '';
  const apptProcStr = nextAppt?.procedure ? `${nextAppt.procedure} ` : '';

  return [
    {
      category: 'Randevu & Karşılama',
      icon: 'heroicons:calendar',
      items: [
        {
          id: 'appt_reminder',
          label: 'Randevu Hatırlatma',
          desc: 'Tarih ve saat bilgili randevu hatırlatması',
          text: `Sayın ${fullName}, ${clinicName}'ndeki ${apptProcStr}randevunuz ${apptDateStr} ${apptTimeStr} için planlanmıştır. Bir değişiklik olması durumunda lütfen bize bilgi veriniz. Sağlıklı günler dileriz.`
        },
        {
          id: 'clinic_location',
          label: 'Klinik Konumu Paylaş',
          desc: 'Google Haritalar yol tarifi linki',
          text: `Merhaba ${fullName}, ${clinicName} adresimize rahatça ulaşabilmeniz için harita konumumuz:\n📍 ${clinicMapsUrl}\nSağlıklı günler dileriz!`
        },
        {
          id: 'lab_arrived',
          label: 'Laboratuvar / Protez Geldi',
          desc: 'Kuron/protez hazır seans bildirimi',
          text: `Sayın ${fullName}, laboratuvara gönderilen protez/kaplama işiniz kliniğimize ulaşmıştır. Prova ve yapıştırma seansınız için randevu oluşturmak üzere bize yazabilirsiniz.`
        }
      ]
    },
    {
      category: 'Tedavi Sonrası Bakım (Post-Op)',
      icon: 'heroicons:heart',
      items: [
        {
          id: 'postop_surgery',
          label: 'Çekim / İmplant Sonrası Bakım',
          desc: 'Tampon, tükürme ve buz kompresi uyarısı',
          text: `Geçmiş olsun ${fullName}.\n\nCerrahi işlem sonrası dikkat edilmesi gerekenler:\n• Tamponu 30 dakika boyunca sıkıca ısırınız ve atınız.\n• İlk 24 saat kesinlikle tükürmeyiniz, ağzınızı çalkalamayınız ve pipet kullanmayınız.\n• Bölgeye dışarıdan aralıklarla soğuk buz kompresi uygulayınız.\n• İlk gün sıcak, taneli ve asitli gıdalardan kaçınınız.\n• İlaçlarınızı saatinde kullanınız. Beklenmedik bir durumda bize ulaşabilirsiniz.`
        },
        {
          id: 'postop_rootcanal',
          label: 'Kanal Tedavisi Sonrası',
          desc: 'Uyuşukluk ve çiğneme hassasiyeti uyarısı',
          text: `Geçmiş olsun ${fullName}.\n\nKanal tedavisi uygulanan dişinizde uyuşukluk geçtikten sonra birkaç gün hafif baskı ve çiğneme hassasiyeti olması normaldir. İlk 2 saat yemek yemeyiniz. Şiddetli zonklama veya şişlik hissederseniz lütfen bize bildiriniz.`
        },
        {
          id: 'postop_bleaching',
          label: 'Beyazlatma (Bleaching) Diyeti',
          desc: '48 saat renklendirici gıda yasağı',
          text: `Yeni gülüşünüz hayırlı olsun ${fullName}!\n\nBeyazlatma işleminin kalıcılığı için ilk 48 saat "beyaz diyet" uygulayınız: Çay, kahve, salça, kola, sigara vb. renklendirici ürünlerden uzak durunuz.`
        },
        {
          id: 'postop_checkin',
          label: 'Ertesi Gün Durum Takibi',
          desc: 'Tedavi sonrası durum ve şikayet kontrolü',
          text: `Merhaba ${fullName}, dün gerçekleştirdiğimiz tedavi sonrasında genel durumunuzu öğrenmek istedik. Herhangi bir ağrı veya beklenmedik bir şikayetiniz var mı? Size yardımcı olabileceğimiz bir durum varsa lütfen yazınız.`
        }
      ]
    },
    {
      category: 'Finans & Cari',
      icon: 'heroicons:credit-card',
      items: [
        {
          id: 'balance_info',
          label: 'Kalan Bakiye Bilgisi',
          desc: 'Güncel borç durumu bilgilendirmesi',
          text: `Sayın ${fullName}, kliniğimizdeki mevcut tedavi sürecinize ait kalan bakiyeniz ${formatCurrency(balance)} olarak görünmektedir. Detaylı bilgi için kliniğimizle iletişime geçebilirsiniz.`
        }
      ]
    }
  ];
});

// Doğrudan Metin ile WhatsApp Aç
const sendWhatsAppText = (messageText) => {
  isWhatsAppMenuOpen.value = false;
  const phone = patientData.value?.patient?.phone;
  if (!phone) {
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Hastaya ait telefon numarası bulunamadı.', type: 'error' }
    }));
    return;
  }
  const url = getWhatsAppUrl(phone, messageText);
  window.open(url, '_blank');
};

// Önizleme ve Özel Mesaj Modalı Aç
const openCustomWhatsAppModal = (templateId = 'appt_reminder') => {
  isWhatsAppMenuOpen.value = false;
  selectedTemplateId.value = templateId;
  
  // Şablonu bul
  for (const group of whatsAppTemplateGroups.value) {
    const found = group.items.find(i => i.id === templateId);
    if (found) {
      customWhatsAppText.value = found.text;
      break;
    }
  }
  isCustomWhatsAppModalOpen.value = true;
};

// Modal İçinde Şablon Değiştir
const applyTemplateItem = (item) => {
  selectedTemplateId.value = item.id;
  customWhatsAppText.value = item.text;
};

// Özel Mesajı WhatsApp'ta Aç
const sendCustomWhatsApp = () => {
  const phone = patientData.value?.patient?.phone;
  if (!phone || !customWhatsAppText.value) return;
  const url = getWhatsAppUrl(phone, customWhatsAppText.value);
  window.open(url, '_blank');
  isCustomWhatsAppModalOpen.value = false;
};

// Dışarı tıklandığında menüyü kapat
const handleClickOutside = (e) => {
  if (whatsappDropdownRef.value && !whatsappDropdownRef.value.contains(e.target)) {
    isWhatsAppMenuOpen.value = false;
  }
};

onMounted(() => {
  loadPatientDetails();
  document.addEventListener('click', handleClickOutside);
});

onUnmounted(() => {
  document.removeEventListener('click', handleClickOutside);
});
</script>
