<template>
  <div class="flex flex-col gap-8">
    
    <!-- Üst Başlık ve Tahsilat Ekle Butonu -->
    <div class="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <h2 class="text-2xl font-bold text-slate-800 dark:text-white tracking-tight">Klinik Muhasebe ve Ödemeler</h2>
        <p class="text-base text-slate-500 dark:text-slate-400 font-medium">Genel cari işlemler listesi, poliklinik gelirleri ve tahsilat kayıtları.</p>
      </div>
      <div class="flex items-center gap-2">
        <button
          @click="openPaymentModal"
          class="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold shadow-md shadow-emerald-600/10 hover:shadow-emerald-600/20 active:scale-95 transition-all duration-150 shadow-sm"
        >
          <Icon name="heroicons:currency-dollar" class="w-4 h-4" />
          <span>Yeni Tahsilat Kaydet</span>
        </button>
      </div>
    </div>

    <!-- Genel Finansal Durum Kartları (İnteraktif Filtreleme) -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
      
      <!-- Toplam Yapılan Tedavi (Tümü / Hepsi) -->
      <div
        @click="setFilter('all')"
        :class="[
          'p-5 rounded-2xl shadow-sm flex items-center justify-between cursor-pointer select-none transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md border',
          activeFilter === 'all'
            ? 'ring-2 ring-slate-400 dark:ring-slate-500 bg-slate-50/80 dark:bg-slate-800/60 border-slate-300 dark:border-slate-600'
            : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
        ]"
        title="Tüm hareketleri listelemek için tıklayın"
      >
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="text-sm text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Toplam Yapılan Tedavi</span>
            <span v-if="activeFilter === 'all'" class="px-1.5 py-0.5 text-[10px] font-bold rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">Seçili</span>
          </div>
          <span class="text-3xl font-black text-slate-800 dark:text-slate-100 font-mono block mt-1.5 leading-none">
            {{ formatCurrency((stats?.totalRevenue || 0) + (stats?.totalDebt || 0)) }}
          </span>
          <span class="text-xs text-slate-400 dark:text-slate-500 font-semibold block mt-1">
            Tamamlanan tedavilerin toplam bedeli (Tümü)
          </span>
        </div>
        <div class="w-12 h-12 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center shrink-0">
          <Icon name="heroicons:document-text" class="w-6 h-6" />
        </div>
      </div>

      <!-- Toplam Tahsilat (Sadece Alınan Ödemeler) -->
      <div
        @click="setFilter('payment')"
        :class="[
          'p-5 rounded-2xl shadow-sm flex items-center justify-between cursor-pointer select-none transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md border',
          activeFilter === 'payment'
            ? 'ring-2 ring-emerald-500 dark:ring-emerald-400 bg-emerald-50/50 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-700'
            : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 hover:border-emerald-200 dark:hover:border-emerald-900/50'
        ]"
        title="Sadece alınan ödemeleri listelemek için tıklayın"
      >
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="text-sm text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Toplam Tahsil Edilen</span>
            <span v-if="activeFilter === 'payment'" class="px-1.5 py-0.5 text-[10px] font-bold rounded bg-emerald-100 dark:bg-emerald-900/50 text-emerald-800 dark:text-emerald-300">Seçili</span>
          </div>
          <span class="text-3xl font-black text-emerald-600 dark:text-emerald-400 font-mono block mt-1.5 leading-none">
            {{ formatCurrency(stats?.totalRevenue) }}
          </span>
          <span class="text-xs text-slate-400 dark:text-slate-500 font-semibold block mt-1">
            Kasalara giren toplam nakit/kart hacmi
          </span>
        </div>
        <div class="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
          <Icon name="heroicons:banknotes" class="w-6 h-6" />
        </div>
      </div>

      <!-- Toplam Alacak (Kalan Bekleyen Alacaklar) -->
      <div
        @click="setFilter('treatment')"
        :class="[
          'p-5 rounded-2xl shadow-sm flex items-center justify-between cursor-pointer select-none transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md border',
          activeFilter === 'treatment'
            ? 'ring-2 ring-rose-500 dark:ring-rose-400 bg-rose-50/50 dark:bg-rose-950/30 border-rose-300 dark:border-rose-700'
            : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 hover:border-rose-200 dark:hover:border-rose-900/50'
        ]"
        title="Sadece kalan bekleyen alacak / borç kayıtlarını listelemek için tıklayın"
      >
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="text-sm text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Kalan Bekleyen Alacak</span>
            <span v-if="activeFilter === 'treatment'" class="px-1.5 py-0.5 text-[10px] font-bold rounded bg-rose-100 dark:bg-rose-900/50 text-rose-800 dark:text-rose-300">Seçili</span>
          </div>
          <span class="text-3xl font-black text-rose-600 dark:text-rose-400 font-mono block mt-1.5 leading-none">
            {{ formatCurrency(stats?.totalDebt) }}
          </span>
          <span class="text-xs text-slate-400 dark:text-slate-500 font-semibold block mt-1">
            Hala tahsil edilmemiş borç bakiyeleri
          </span>
        </div>
        <div class="w-12 h-12 rounded-xl bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
          <Icon name="heroicons:credit-card" class="w-6 h-6" />
        </div>
      </div>

    </div>

    <!-- Genel Cari Hareket Tablosu -->
    <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
      <div class="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div class="flex items-center gap-3">
          <h3 class="font-bold text-slate-800 dark:text-white text-base uppercase tracking-wider">
            {{
              activeFilter === 'payment'
                ? 'Alınan Ödemeler (Tahsilatlar)'
                : activeFilter === 'treatment'
                  ? 'Kalan Bekleyen Alacaklar (Tedavi Borçları)'
                  : 'Tüm Cari Hareket Kayıtları'
            }}
          </h3>
          <button
            v-if="activeFilter !== 'all'"
            @click="activeFilter = 'all'"
            class="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors"
            title="Tüm hareketleri göster"
          >
            <Icon name="heroicons:x-mark" class="w-3.5 h-3.5" />
            <span>Filtreyi Temizle</span>
          </button>
        </div>
        <span class="px-2.5 py-0.5 rounded-full text-sm font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
          Toplam İşlem: {{ filteredLedgerItems.length }}
        </span>
      </div>

      <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse text-sm">
          <thead>
            <tr class="bg-slate-50 dark:bg-slate-950/10 border-b border-slate-100 dark:border-slate-800 text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider text-sm">
              <th class="px-6 py-3.5">Tarih</th>
              <th class="px-6 py-3.5">Hasta Adı</th>
              <th class="px-6 py-3.5">İşlem Türü</th>
              <th class="px-6 py-3.5">Detaylar / Açıklama</th>
              <th class="px-6 py-3.5 text-right">Tutar</th>
              <th class="px-6 py-3.5 text-right">Eylemler</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
            <tr v-if="isLoading">
              <td colspan="6" class="px-6 py-12 text-center text-slate-400 dark:text-slate-500 font-medium text-sm">
                <Icon name="heroicons:arrow-path" class="w-6 h-6 animate-spin text-teal-600 inline-block mb-2" />
                <div>Finansal veriler yükleniyor...</div>
              </td>
            </tr>
            <tr v-else-if="filteredLedgerItems.length === 0">
              <td colspan="6" class="px-6 py-12 text-center text-slate-400 dark:text-slate-500 font-medium text-sm">
                <span v-if="activeFilter === 'payment'">Filtreye uygun tahsilat / ödeme kaydı bulunamadı.</span>
                <span v-else-if="activeFilter === 'treatment'">Filtreye uygun tedavi borcu / alacak kaydı bulunamadı.</span>
                <span v-else>Henüz yapılmış bir finansal hareket bulunmamaktadır.</span>
              </td>
            </tr>
            <tr
              v-else
              v-for="item in filteredLedgerItems"
              :key="item.key"
              class="hover:bg-slate-50/30 dark:hover:bg-slate-800/20 transition-colors"
            >
              <!-- Tarih -->
              <td class="px-6 py-4 font-mono font-semibold text-slate-600 dark:text-slate-300">
                {{ formatDate(item.date) }}
              </td>
              <!-- Hasta Adı -->
              <td class="px-6 py-4 font-bold text-slate-800 dark:text-slate-200">
                <NuxtLink v-if="item.patientId" :to="`/patients/${item.patientId._id}`" class="hover:text-teal-600 dark:hover:text-teal-400 hover:underline block text-sm">
                  {{ item.patientId.firstName }} {{ item.patientId.lastName }}
                </NuxtLink>
                <span v-else class="text-rose-500 dark:text-rose-400">—</span>
              </td>
              <!-- İşlem Türü -->
              <td class="px-6 py-4">
                <span
                  v-if="item.type === 'treatment'"
                  class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 border border-rose-100 dark:border-rose-900/30"
                >
                  Tedavi Borcu
                </span>
                <span
                  v-else
                  class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30"
                >
                  Ödeme Girişi
                </span>
              </td>
              <!-- Detaylar -->
              <td class="px-6 py-4">
                <div class="flex flex-col gap-0.5">
                  <span class="font-semibold text-slate-600 dark:text-slate-300">{{ item.description }}</span>
                  <span v-if="item.tooth" class="text-xs font-bold text-teal-500 dark:text-teal-400 font-mono">Diş: {{ item.tooth }}</span>
                  <span v-if="item.notes" class="text-xs text-slate-400 dark:text-slate-500 font-medium">{{ item.notes }}</span>
                </div>
              </td>
              <!-- Tutar -->
              <td
                :class="[
                  item.type === 'treatment' ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400',
                  'px-6 py-4 text-right font-black font-mono text-base'
                ]"
              >
                {{ item.type === 'treatment' ? '-' : '+' }}{{ formatCurrency(item.amount) }}
              </td>
              <!-- Eylemler (Düzenleme & Silme) -->
              <td class="px-6 py-4 text-right">
                <div class="flex items-center justify-end gap-1">
                  <button
                    @click="openEditModal(item)"
                    class="p-1.5 text-slate-400 dark:text-slate-500 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                    title="İşlemi Düzenle"
                  >
                    <Icon name="heroicons:pencil-square" class="w-4 h-4" />
                  </button>
                  <button
                    @click="confirmDelete(item)"
                    class="p-1.5 text-slate-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                    title="İşlemi Sil"
                  >
                    <Icon name="heroicons:trash" class="w-4 h-4" />
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Ödeme Tahsilat Modalı -->
    <AppModal
      :isOpen="isPaymentModalOpen"
      :title="editingPaymentId ? '✏️ Ödeme Tahsilatını Düzenle' : '💵 Klinik Ödeme Tahsilat Kaydı'"
      width="md"
      @close="isPaymentModalOpen = false"
    >
      <form @submit.prevent="savePayment" class="space-y-4">
        <!-- Hasta Seçimi -->
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Ödeme Yapan Hasta <span class="text-rose-500">*</span></label>
          <PatientSearchSelect
            v-model="form.patientId"
            :patients="patients"
            placeholder="Hasta adı veya telefon numarası yazın..."
            :required="true"
          />
        </div>

        <div class="grid grid-cols-2 gap-3">
          <!-- Tutar -->
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Miktar (TL) <span class="text-rose-500">*</span></label>
            <input
              v-model.number="form.amount"
              type="number"
              min="0.01"
              step="any"
              required
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
          <!-- Yöntem -->
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Ödeme Yöntemi <span class="text-rose-500">*</span></label>
            <select
              v-model="form.method"
              required
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            >
              <option v-for="m in PAYMENT_METHODS" :key="m.value" :value="m.value" class="bg-white dark:bg-slate-800 text-slate-800 dark:text-white">
                {{ m.icon }} {{ m.label }}
              </option>
            </select>
          </div>
        </div>

        <!-- Tarih -->
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Ödeme Tarihi <span class="text-rose-500">*</span></label>
          <input
            v-model="form.date"
            type="date"
            required
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          />
        </div>

        <!-- Açıklama Notu -->
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Açıklama Notu</label>
          <textarea
            v-model="form.notes"
            rows="2"
            placeholder="Dekont no, elden nakit ödeme vb..."
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          ></textarea>
        </div>
      </form>

      <template #footer>
        <button
          @click="isPaymentModalOpen = false"
          class="px-4 py-2 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
        >
          İptal
        </button>
        <button
          @click="savePayment"
          :disabled="isSaving"
          class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-400 text-white rounded-xl text-sm font-bold shadow-sm transition-all"
        >
          {{ editingPaymentId ? 'Değişiklikleri Kaydet' : 'Ödemeyi Al' }}
        </button>
      </template>
    </AppModal>

    <!-- Tedavi İşlemi Düzenleme Modalı -->
    <AppModal
      :isOpen="isTreatmentModalOpen"
      title="✏️ Tedavi İşlemini Düzenle"
      width="md"
      @close="isTreatmentModalOpen = false"
    >
      <form @submit.prevent="saveTreatment" class="space-y-4">
        <!-- Hasta Seçimi -->
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Hasta <span class="text-rose-500">*</span></label>
          <PatientSearchSelect
            v-model="treatmentForm.patientId"
            :patients="patients"
            placeholder="Hasta seçin..."
            :required="true"
          />
        </div>

        <!-- Yapılan İşlem & Diş -->
        <div class="grid grid-cols-3 gap-3">
          <div class="col-span-2">
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Yapılan İşlem <span class="text-rose-500">*</span></label>
            <input
              v-model="treatmentForm.procedure"
              type="text"
              required
              placeholder="Örn: Kompozit Dolgu"
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Diş No</label>
            <input
              v-model="treatmentForm.tooth"
              type="text"
              placeholder="Örn: 36"
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
        </div>

        <!-- Tutar & Tarih -->
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">İşlem Ücreti (TL) <span class="text-rose-500">*</span></label>
            <input
              v-model.number="treatmentForm.fee"
              type="number"
              min="0"
              step="any"
              required
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Tarih <span class="text-rose-500">*</span></label>
            <input
              v-model="treatmentForm.date"
              type="date"
              required
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all font-mono bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
        </div>

        <!-- Notlar -->
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">Açıklama Notu</label>
          <textarea
            v-model="treatmentForm.notes"
            rows="2"
            placeholder="İşlem detayları veya hekim açıklaması..."
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 dark:focus:border-teal-500 focus:ring-2 focus:ring-teal-500/15 dark:focus:ring-teal-500/20 text-sm transition-all bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          ></textarea>
        </div>
      </form>

      <template #footer>
        <button
          @click="isTreatmentModalOpen = false"
          class="px-4 py-2 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
        >
          İptal
        </button>
        <button
          @click="saveTreatment"
          :disabled="isSaving"
          class="px-4 py-2 bg-teal-600 hover:bg-teal-700 disabled:bg-teal-400 text-white rounded-xl text-sm font-bold shadow-sm transition-all"
        >
          Değişiklikleri Kaydet
        </button>
      </template>
    </AppModal>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useUtils } from '~/composables/useUtils';

const {
  formatDate,
  formatCurrency,
  PAYMENT_METHODS,
  todayStr
} = useUtils();

const stats = ref(null);
const patients = ref([]);
const treatments = ref([]);
const payments = ref([]);
const isLoading = ref(false);
const isSaving = ref(false);
const isPaymentModalOpen = ref(false);
const isTreatmentModalOpen = ref(false);
const editingPaymentId = ref(null);
const editingTreatmentId = ref(null);

const defaultForm = {
  patientId: '',
  amount: 0,
  method: 'cash',
  date: todayStr(),
  notes: ''
};
const form = ref({ ...defaultForm });

const defaultTreatmentForm = {
  patientId: '',
  procedure: '',
  tooth: '',
  fee: 0,
  date: todayStr(),
  notes: ''
};
const treatmentForm = ref({ ...defaultTreatmentForm });

// Finansal özet istatistiklerini yükle
const loadStats = async () => {
  try {
    const data = await $fetch('/api/stats');
    stats.value = data;
  } catch (error) {
    console.error(error);
  }
};

// Tüm cari hareketleri (tedaviler ve ödemeler) yükle
const loadLedger = async () => {
  try {
    const [tData, pData] = await Promise.all([
      $fetch('/api/treatments'),
      $fetch('/api/payments')
    ]);
    treatments.value = tData;
    payments.value = pData;
  } catch (error) {
    console.error(error);
  }
};

// Tüm hastaları çek (Dropdown hasta eşleme için)
const loadPatients = async () => {
  try {
    const data = await $fetch('/api/patients');
    patients.value = data;
  } catch (error) {
    console.error(error);
  }
};

const loadAll = async () => {
  isLoading.value = true;
  await Promise.all([loadStats(), loadLedger()]);
  isLoading.value = false;
};

// Tedavileri ve ödemeleri birleştirerek genel cari listeyi kronolojik oluşturur
const ledgerItems = computed(() => {
  const items = [];

  // Tedavileri ekle
  treatments.value.forEach((t) => {
    items.push({
      key: `t-${t._id}`,
      id: t._id,
      patientId: t.patientId, // populated
      type: 'treatment',
      date: t.date,
      description: t.procedure,
      tooth: t.tooth,
      notes: t.notes,
      amount: t.fee,
      rawCreatedAt: t.createdAt
    });
  });

  // Ödemeleri ekle
  payments.value.forEach((p) => {
    const methodLabel = PAYMENT_METHODS.find(m => m.value === p.method)?.label || p.method;
    items.push({
      key: `p-${p._id}`,
      id: p._id,
      patientId: p.patientId, // populated
      type: 'payment',
      date: p.date,
      description: `Ödeme Tahsilatı (${methodLabel})`,
      method: p.method,
      notes: p.notes,
      amount: p.amount,
      rawCreatedAt: p.createdAt
    });
  });

  // Tarihe göre en yeni üstte sırala
  return items.sort((a, b) => {
    const dComp = b.date.localeCompare(a.date);
    if (dComp !== 0) return dComp;
    return new Date(b.rawCreatedAt).getTime() - new Date(a.rawCreatedAt).getTime();
  });
});

// Filtreleme Durumu ('all' | 'payment' | 'treatment')
const activeFilter = ref('all');

const setFilter = (filterType) => {
  if (filterType === 'all') {
    activeFilter.value = 'all';
  } else {
    // Tıklanan filtre zaten aktifse tümüne dön, değilse o filtreyi uygula
    activeFilter.value = activeFilter.value === filterType ? 'all' : filterType;
  }
};

// Aktif filtreye göre filtrelenmiş cari liste
const filteredLedgerItems = computed(() => {
  if (activeFilter.value === 'payment') {
    return ledgerItems.value.filter(item => item.type === 'payment');
  }
  if (activeFilter.value === 'treatment') {
    return ledgerItems.value.filter(item => item.type === 'treatment');
  }
  return ledgerItems.value;
});

// Yeni Ödeme Girişi Modalı Aç
const openPaymentModal = async () => {
  editingPaymentId.value = null;
  form.value = { ...defaultForm };
  isPaymentModalOpen.value = true;
  await loadPatients();
};

// İşlem Düzenleme Modalı Aç (Ödeme veya Tedavi)
const openEditModal = async (item) => {
  await loadPatients();
  const patientIdVal = item.patientId && typeof item.patientId === 'object'
    ? item.patientId._id
    : (item.patientId || '');

  if (item.type === 'payment') {
    editingPaymentId.value = item.id;
    form.value = {
      patientId: patientIdVal,
      amount: item.amount,
      method: item.method || 'cash',
      date: item.date || todayStr(),
      notes: item.notes || ''
    };
    isPaymentModalOpen.value = true;
  } else if (item.type === 'treatment') {
    editingTreatmentId.value = item.id;
    treatmentForm.value = {
      patientId: patientIdVal,
      procedure: item.description || '',
      tooth: item.tooth || '',
      fee: item.amount || 0,
      date: item.date || todayStr(),
      notes: item.notes || ''
    };
    isTreatmentModalOpen.value = true;
  }
};

// Ödemeyi Kaydet (Yeni Ekle veya Güncelle)
const savePayment = async () => {
  if (!form.value.patientId || !form.value.amount || !form.value.method) {
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Lütfen zorunlu alanları doldurun.', type: 'error' }
    }));
    return;
  }

  try {
    isSaving.value = true;
    if (editingPaymentId.value) {
      await $fetch(`/api/payments/${editingPaymentId.value}`, {
        method: 'PUT',
        body: form.value
      });

      window.dispatchEvent(new CustomEvent('toast-message', {
        detail: { message: 'Ödeme tahsilatı başarıyla güncellendi.', type: 'success' }
      }));
    } else {
      await $fetch('/api/payments', {
        method: 'POST',
        body: form.value
      });

      window.dispatchEvent(new CustomEvent('toast-message', {
        detail: { message: 'Ödeme tahsilatı başarıyla kaydedildi.', type: 'success' }
      }));
    }

    isPaymentModalOpen.value = false;
    await loadAll();
    window.dispatchEvent(new CustomEvent('refresh-stats'));
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: error?.data?.message || 'İşlem sırasında hata oluştu.', type: 'error' }
    }));
  } finally {
    isSaving.value = false;
  }
};

// Tedavi İşlemini Güncelle
const saveTreatment = async () => {
  if (!treatmentForm.value.patientId || !treatmentForm.value.procedure || treatmentForm.value.fee == null) {
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Lütfen zorunlu alanları doldurun.', type: 'error' }
    }));
    return;
  }

  try {
    isSaving.value = true;
    await $fetch(`/api/treatments/${editingTreatmentId.value}`, {
      method: 'PUT',
      body: treatmentForm.value
    });

    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Tedavi işlemi başarıyla güncellendi.', type: 'success' }
    }));

    isTreatmentModalOpen.value = false;
    await loadAll();
    window.dispatchEvent(new CustomEvent('refresh-stats'));
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: error?.data?.message || 'Tedavi güncellenirken hata oluştu.', type: 'error' }
    }));
  } finally {
    isSaving.value = false;
  }
};

// Cari işlem sil
const confirmDelete = (item) => {
  const patientName = item.patientId ? `${item.patientId.firstName} ${item.patientId.lastName}` : 'Hasta';
  const confirmText = `${patientName} isimli hastaya ait "${item.description}" cari hareketini silmek istediğinize emin misiniz?`;
  if (window.confirm(confirmText)) {
    deleteLedgerItem(item);
  }
};

const deleteLedgerItem = async (item) => {
  try {
    const endpoint = item.type === 'treatment' ? `/api/treatments/${item.id}` : `/api/payments/${item.id}`;
    await $fetch(endpoint, { method: 'DELETE' });

    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Cari işlem silindi.', type: 'success' }
    }));

    await loadAll();
    window.dispatchEvent(new CustomEvent('refresh-stats'));
  } catch (error) {
    console.error(error);
    window.dispatchEvent(new CustomEvent('toast-message', {
      detail: { message: 'Silme işlemi sırasında hata oluştu.', type: 'error' }
    }));
  }
};

onMounted(() => {
  loadAll();
});
</script>
