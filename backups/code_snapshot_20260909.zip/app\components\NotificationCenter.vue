<template>
  <div class="relative" ref="dropdownRef">
    <!-- Bildirim Zili Butonu & Kırmızı Sayaç -->
    <button
      @click="toggleDropdown"
      class="relative p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all duration-200 focus:outline-none"
      title="Bildirimler ve Geri Çağırma (Recall) Merkezi"
    >
      <Icon name="heroicons:bell" class="w-6 h-6" />
      
      <!-- Canlı Kırmızı Bildirim Rozeti -->
      <span
        v-if="totalBadgeCount > 0"
        class="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-extrabold text-white ring-2 ring-white dark:ring-slate-900 animate-pulse"
      >
        {{ totalBadgeCount > 9 ? '9+' : totalBadgeCount }}
      </span>
    </button>

    <!-- Bildirim & Recall Paneli Dropdown -->
    <Transition
      enter-active-class="transition duration-200 ease-out"
      enter-from-class="transform opacity-0 scale-95 -translate-y-2"
      enter-to-class="transform opacity-100 scale-100 translate-y-0"
      leave-active-class="transition duration-150 ease-in"
      leave-from-class="transform opacity-100 scale-100 translate-y-0"
      leave-to-class="transform opacity-0 scale-95 -translate-y-2"
    >
      <div
        v-if="isOpen"
        class="fixed inset-x-3 top-18 sm:inset-auto sm:absolute sm:right-0 sm:top-full sm:mt-3 sm:w-[420px] max-w-[420px] mx-auto rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl z-50 overflow-hidden flex flex-col max-h-[80vh] sm:max-h-[620px]"
      >
        <!-- Panel Başlığı -->
        <div class="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-950/40">
          <div class="flex items-center gap-2">
            <span class="text-xl">🔔</span>
            <div>
              <h3 class="font-bold text-slate-800 dark:text-white text-sm leading-tight">Bildirim & Hatırlatma Merkezi</h3>
              <p class="text-[11px] text-slate-400">Recall kontrolleri ve randevu takibi</p>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <button
              @click="refreshAll"
              :disabled="isLoading"
              class="p-1.5 text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 rounded-lg transition-colors"
              title="Yenile"
            >
              <Icon name="heroicons:arrow-path" :class="['w-4 h-4', isLoading ? 'animate-spin' : '']" />
            </button>
            <button
              @click="isOpen = false"
              class="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
            >
              <Icon name="heroicons:x-mark" class="w-4 h-4" />
            </button>
          </div>
        </div>

        <!-- Sekmeler: Geri Çağırma (Recall) vs Randevular -->
        <div class="p-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-950/20">
          <div class="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl">
            <button
              type="button"
              @click="activeSubTab = 'recalls'"
              :class="[
                activeSubTab === 'recalls'
                  ? 'bg-white dark:bg-slate-900 text-slate-800 dark:text-white shadow-sm font-bold'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200',
                'flex-1 py-1.5 px-3 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5'
              ]"
            >
              <span>⚠️ Geri Çağırma</span>
              <span
                v-if="recalls.length > 0"
                class="px-1.5 py-0.2 bg-rose-500 text-white rounded-full text-[10px] font-extrabold"
              >
                {{ recalls.length }}
              </span>
            </button>

            <button
              type="button"
              @click="activeSubTab = 'appointments'"
              :class="[
                activeSubTab === 'appointments'
                  ? 'bg-white dark:bg-slate-900 text-slate-800 dark:text-white shadow-sm font-bold'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200',
                'flex-1 py-1.5 px-3 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5'
              ]"
            >
              <span>📅 Randevular</span>
              <span
                v-if="todayNotifications.length > 0"
                class="px-1.5 py-0.2 bg-teal-500 text-white rounded-full text-[10px] font-extrabold"
              >
                {{ todayNotifications.length }}
              </span>
            </button>
          </div>
        </div>

        <!-- Mobil Bildirim İzni İsteme (Yalnızca izin verilmemişse görünür) -->
        <div v-if="permission !== 'granted'" class="px-3 pt-2.5">
          <div
            class="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 dark:border-amber-500/30 flex items-center justify-between gap-2"
          >
            <div class="flex items-center gap-2 min-w-0">
              <span class="text-base shrink-0">📱</span>
              <div class="min-w-0">
                <div class="text-[11px] font-bold text-amber-900 dark:text-amber-200 truncate">Mobil Bildirimler Kapalı</div>
                <div class="text-[10px] text-amber-700/80 dark:text-amber-300/70 truncate">Randevuları kilit ekranına al</div>
              </div>
            </div>
            <button
              type="button"
              @click="requestPermission"
              class="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white rounded-xl text-[11px] font-bold shrink-0 shadow-sm transition-all flex items-center gap-1"
            >
              <span>İzin Ver</span>
            </button>
          </div>
        </div>

        <!-- İçerik Alanı -->
        <div class="overflow-y-auto flex-1 p-3 space-y-3">
          <!-- 1. GERİ ÇAĞIRMA (RECALL) LİSTESİ -->
          <div v-if="activeSubTab === 'recalls'" class="space-y-2.5">
            <div v-if="isLoadingRecalls" class="py-10 text-center text-slate-400 text-xs">
              <Icon name="heroicons:arrow-path" class="w-5 h-5 animate-spin mx-auto mb-2 text-teal-600" />
              <span>Geri çağırma listesi kontrol ediliyor...</span>
            </div>

            <div v-else-if="recalls.length === 0" class="py-10 text-center flex flex-col items-center gap-2">
              <div class="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center text-xl">
                ✓
              </div>
              <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Vakti gelen hasta bulunmuyor</span>
              <span class="text-[11px] text-slate-400 max-w-xs">
                6 aylık rutin kontrolü veya 3 aylık implant protez süresi dolan hasta kaydı yok.
              </span>
            </div>

            <div
              v-else
              v-for="item in recalls"
              :key="item.patientId"
              class="p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900/60 shadow-sm hover:shadow-md transition-all flex flex-col gap-2.5"
            >
              <div class="flex items-start justify-between gap-2">
                <div>
                  <NuxtLink
                    :to="`/patients/${item.patientId}`"
                    @click="isOpen = false"
                    class="font-bold text-sm text-slate-800 dark:text-white hover:text-teal-600 dark:hover:text-teal-400 transition-colors inline-flex items-center gap-1"
                  >
                    <span>{{ item.fullName }}</span>
                    <Icon name="heroicons:arrow-top-right-on-square" class="w-3.5 h-3.5 opacity-60" />
                  </NuxtLink>
                  <p class="text-xs font-semibold text-rose-600 dark:text-rose-400 mt-0.5 flex items-center gap-1">
                    <span>⚠️</span>
                    <span>{{ item.reason }}</span>
                  </p>
                </div>

                <span class="px-2 py-0.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-[10px] font-bold shrink-0 border border-rose-200/60">
                  {{ item.daysPassed }} gün önce
                </span>
              </div>

              <div class="text-[11px] text-slate-400 flex items-center gap-2">
                <span>Son İşlem: <strong>{{ formatDate(item.lastTreatmentDate) }}</strong></span>
                <span v-if="item.phone" class="font-mono text-slate-500">• {{ item.phone }}</span>
              </div>

              <!-- Tek Tıkla WhatsApp Hatırlatma Butonu -->
              <button
                type="button"
                @click="handleSendRecallReminder(item)"
                class="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 bg-[#16a34a] hover:bg-[#15803d] active:scale-98 text-white rounded-xl text-xs font-bold shadow-sm shadow-emerald-600/20 transition-all"
              >
                <Icon name="heroicons:chat-bubble-left-right" class="w-3.5 h-3.5" />
                <span>💬 WhatsApp ile Kontrole Çağır</span>
              </button>
            </div>
          </div>

          <!-- 2. YAKLAŞAN RANDEVULAR LİSTESİ -->
          <div v-else class="space-y-3">
            <div v-if="notifications.length === 0" class="py-10 text-center flex flex-col items-center gap-2">
              <span class="text-3xl opacity-50">🗓️</span>
              <span class="text-xs font-medium text-slate-400">Yaklaşan bir randevu bulunmuyor.</span>
            </div>

            <div v-else>
              <!-- Bugünkü Randevular -->
              <div v-if="todayNotifications.length > 0" class="mb-3">
                <div class="px-2 py-1 text-[11px] font-bold text-rose-500 uppercase tracking-wider flex items-center justify-between">
                  <span>🔥 Bugünkü Randevular</span>
                  <span class="bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 px-1.5 py-0.5 rounded text-[10px]">
                    {{ todayNotifications.length }}
                  </span>
                </div>

                <div class="space-y-1.5 mt-1">
                  <div
                    v-for="item in todayNotifications"
                    :key="item.id"
                    class="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-all border border-slate-100 dark:border-slate-800/80 group gap-2"
                  >
                    <NuxtLink
                      :to="item.patientId ? `/patients/${item.patientId}` : '/appointments'"
                      @click="isOpen = false"
                      class="flex items-start gap-2.5 flex-1 min-w-0"
                    >
                      <div class="w-8 h-8 rounded-lg bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                        {{ item.time }}
                      </div>
                      <div class="flex flex-col min-w-0">
                        <span class="font-bold text-xs text-slate-800 dark:text-white group-hover:text-teal-600 transition-colors truncate">
                          {{ item.patientName }}
                        </span>
                        <span class="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {{ item.procedure }}
                        </span>
                      </div>
                    </NuxtLink>

                    <span
                      :class="[
                        item.isUrgent
                          ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/50'
                          : 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-900/50',
                        'px-2 py-0.5 rounded-full text-[10px] font-bold border shrink-0'
                      ]"
                    >
                      {{ item.timeLabel }}
                    </span>
                  </div>
                </div>
              </div>

              <!-- Yarınki Randevular -->
              <div v-if="tomorrowNotifications.length > 0">
                <div class="px-2 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  📅 Yarınki Randevular
                </div>

                <div class="space-y-1.5 mt-1">
                  <NuxtLink
                    v-for="item in tomorrowNotifications"
                    :key="item.id"
                    :to="item.patientId ? `/patients/${item.patientId}` : '/appointments'"
                    @click="isOpen = false"
                    class="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-all border border-slate-100 dark:border-slate-800/80 group"
                  >
                    <div class="flex items-start gap-2.5">
                      <div class="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                        {{ item.time }}
                      </div>
                      <div class="flex flex-col">
                        <span class="font-bold text-xs text-slate-800 dark:text-white group-hover:text-teal-600 transition-colors">
                          {{ item.patientName }}
                        </span>
                        <span class="text-[11px] text-slate-500 dark:text-slate-400">
                          {{ item.procedure }}
                        </span>
                      </div>
                    </div>

                    <span class="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-full text-[10px] font-bold">
                      Yarın
                    </span>
                  </NuxtLink>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Panel Altlığı -->
        <div class="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/20 text-center flex items-center justify-between text-xs font-bold">
          <NuxtLink
            to="/appointments"
            @click="isOpen = false"
            class="text-teal-600 dark:text-teal-400 hover:underline inline-flex items-center gap-1"
          >
            <span>Randevu Takvimi</span>
            <Icon name="heroicons:arrow-right" class="w-3.5 h-3.5" />
          </NuxtLink>

          <NuxtLink
            to="/patients"
            @click="isOpen = false"
            class="text-slate-500 hover:text-slate-800 dark:hover:text-white hover:underline"
          >
            Tüm Hastalar
          </NuxtLink>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { useNotifications } from '~/composables/useNotifications';
import { useUtils } from '~/composables/useUtils';

const {
  notifications,
  isLoading,
  permission,
  requestPermission,
  loadNotifications
} = useNotifications();

const { formatDate } = useUtils();

const isOpen = ref(false);
const activeSubTab = ref<'recalls' | 'appointments'>('recalls');
const dropdownRef = ref<HTMLDivElement | null>(null);

// Recall State
const recalls = ref<any[]>([]);
const isLoadingRecalls = ref(false);

const loadRecalls = async () => {
  try {
    isLoadingRecalls.value = true;
    const res: any = await $fetch('/api/recall');
    if (res && res.success && Array.isArray(res.data)) {
      recalls.value = res.data;
    } else {
      recalls.value = [];
    }
  } catch (error) {
    console.error('Recall verileri alınamadı:', error);
  } finally {
    isLoadingRecalls.value = false;
  }
};

const refreshAll = () => {
  loadNotifications();
  loadRecalls();
};

const toggleDropdown = () => {
  isOpen.value = !isOpen.value;
  if (isOpen.value) {
    refreshAll();
    // Eğer recall varsa direkt recall sekmesi açık gelsin
    if (recalls.value.length > 0) {
      activeSubTab.value = 'recalls';
    } else if (todayNotifications.value.length > 0) {
      activeSubTab.value = 'appointments';
    }
  }
};

const todayNotifications = computed(() => {
  return notifications.value.filter(n => n.type === 'today');
});

const tomorrowNotifications = computed(() => {
  return notifications.value.filter(n => n.type === 'tomorrow');
});

// Toplam Kırmızı Bildirim Rozeti Sayacı (Recall hastaları + Bugünkü randevular)
const totalBadgeCount = computed(() => {
  return recalls.value.length + todayNotifications.value.length;
});

// Recall WhatsApp Hatırlatma Gönder
const handleSendRecallReminder = (patient: any) => {
  let message = "";
  if (patient.recallType === "ROUTINE_CHECKUP") {
    message = `Sayın ${patient.fullName}, kliniğimizdeki son kontrolünüzün üzerinden 6 ay geçmiştir. Ağız ve diş sağlığınızı korumak için 6 aylık rutin kontrol ve bakım randevunuzu oluşturmak ister misiniz? Sağlıklı günler dileriz.`;
  } else if (patient.recallType === "IMPLANT_CROWN_READY") {
    message = `Sayın ${patient.fullName}, implant operasyonunuzun ardından kemik iyileşme süreciniz tamamlanmıştır. Üst porselen/zirkon kaplama aşamasına geçmek üzere prova randevunuz için bize yazabilirsiniz.`;
  } else {
    message = `Sayın ${patient.fullName}, kliniğimizde planlanan tedavinize devam etmek ve kontrol randevunuzu oluşturmak üzere bize yazabilirsiniz. Sağlıklı günler dileriz.`;
  }

  const phoneStr = patient.phone || "";
  let cleanPhone = phoneStr.replace(/\D/g, '');
  if (cleanPhone.startsWith('0')) cleanPhone = cleanPhone.substring(1);
  if (!cleanPhone.startsWith('90')) cleanPhone = '90' + cleanPhone;

  window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`, '_blank');
};

// Dışarıya tıklanınca menüyü kapat
const handleClickOutside = (event: MouseEvent) => {
  if (dropdownRef.value && !dropdownRef.value.contains(event.target as Node)) {
    isOpen.value = false;
  }
};

onMounted(() => {
  document.addEventListener('click', handleClickOutside);
  loadRecalls();
});

onUnmounted(() => {
  document.removeEventListener('click', handleClickOutside);
});
</script>
