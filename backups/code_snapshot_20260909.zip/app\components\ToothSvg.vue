<template>
  <div class="relative flex flex-col items-center group cursor-pointer select-none">
    <!-- Diş SVG Vektör Alanı (1 Önceki Şık 2D Anatomik Model) -->
    <div
      :class="[
        'relative transition-all duration-200 transform group-hover:scale-110 flex items-center justify-center p-1 rounded-xl',
        isSelected ? 'ring-2 ring-teal-500 bg-teal-500/10' : ''
      ]"
      :style="{ width: width + 'px', height: height + 'px' }"
    >
      <svg
        viewBox="0 0 44 68"
        class="w-full h-full drop-shadow-md overflow-visible transition-all duration-200"
        :class="{ 'opacity-35': activeProcedures.includes('missing') }"
      >
        <defs>
          <!-- Şık Medikal Diş Rengi Gradyanları -->
          <linearGradient :id="'toothGrad-' + toothNumber" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#ffffff" />
            <stop offset="65%" stop-color="#f1f5f9" />
            <stop offset="100%" stop-color="#cbd5e1" />
          </linearGradient>

          <linearGradient :id="'rootGrad-' + toothNumber" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#f1f5f9" />
            <stop offset="70%" stop-color="#cbd5e1" />
            <stop offset="100%" stop-color="#94a3b8" />
          </linearGradient>

          <!-- Kuron Kaplama Altın Gradyanı -->
          <linearGradient :id="'crownGrad-' + toothNumber" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#fef08a" />
            <stop offset="50%" stop-color="#f59e0b" />
            <stop offset="100%" stop-color="#b45309" />
          </linearGradient>
        </defs>

        <g :transform="isUpper ? '' : 'rotate(180 22 34)'">
          <!-- 1. ANATOMİK KÖK BÖLÜMÜ (ROOTS) -->
          <g>
            <!-- 3 Kök (Büyük Üst Azılar: 16, 17, 18, 26, 27, 28) -->
            <path
              v-if="toothType === 'molar_upper'"
              d="M 9,32 C 6,18 4,6 10,3 C 14,1 15,14 17,22 C 19,14 21,2 25,2 C 29,2 28,15 31,22 C 33,14 34,4 38,5 C 42,7 39,20 35,32 Z"
              :fill="`url(#rootGrad-${toothNumber})`"
              :stroke="primaryStroke"
              stroke-width="1.8"
              stroke-linejoin="round"
            />

            <!-- 2 Kök (Büyük Alt Azılar: 36..38, 46..48) -->
            <path
              v-else-if="toothType === 'molar_lower'"
              d="M 8,32 C 5,18 4,5 11,3 C 16,1 17,16 22,23 C 27,16 28,1 33,3 C 40,5 39,18 36,32 Z"
              :fill="`url(#rootGrad-${toothNumber})`"
              :stroke="primaryStroke"
              stroke-width="1.8"
              stroke-linejoin="round"
            />

            <!-- 2 Kök (Küçük Azılar: 14, 15, 24, 25, 34, 35, 44, 45) -->
            <path
              v-else-if="toothType === 'premolar'"
              d="M 12,32 C 9,18 11,5 16,3 C 19,2 20,16 22,24 C 24,16 25,2 28,3 C 33,5 33,18 32,32 Z"
              :fill="`url(#rootGrad-${toothNumber})`"
              :stroke="primaryStroke"
              stroke-width="1.8"
              stroke-linejoin="round"
            />

            <!-- Sivri Kök (Köpek Dişleri: 13, 23, 33, 43) -->
            <path
              v-else-if="toothType === 'canine'"
              d="M 14,32 C 12,16 16,2 20,2 C 24,2 28,16 26,28 Z"
              :fill="`url(#rootGrad-${toothNumber})`"
              :stroke="primaryStroke"
              stroke-width="1.8"
              stroke-linejoin="round"
            />

            <!-- İnce Kök (Kesiciler: 11, 12, 21, 22, 31, 32, 41, 42) -->
            <path
              v-else
              d="M 15,32 C 14,17 17,4 20,4 C 23,4 26,17 25,28 Z"
              :fill="`url(#rootGrad-${toothNumber})`"
              :stroke="primaryStroke"
              stroke-width="1.8"
              stroke-linejoin="round"
            />
          </g>

          <!-- 2. KANAL TEDAVİSİ İNDİKATÖRÜ (ROOT CANAL) -->
          <g v-if="activeProcedures.includes('rootcanal')">
            <path
              v-if="toothType.startsWith('molar')"
              d="M 22,8 L 22,32 M 12,8 L 15,28 M 32,8 L 29,28"
              stroke="#ef4444"
              stroke-width="2.2"
              stroke-linecap="round"
            />
            <path
              v-else
              d="M 20,6 L 20,32"
              stroke="#ef4444"
              stroke-width="2.5"
              stroke-linecap="round"
            />
          </g>

          <!-- 3. İMPLANT VİDA KATMANI (IMPLANT SCREW) -->
          <g v-if="activeProcedures.includes('implant')" transform="translate(13, 4)">
            <rect x="3" y="0" width="8" height="22" rx="2" fill="#64748b" stroke="#334155" stroke-width="1.5" />
            <line x1="1" y1="4" x2="13" y2="4" stroke="#e2e8f0" stroke-width="1.5" />
            <line x1="1" y1="8" x2="13" y2="8" stroke="#e2e8f0" stroke-width="1.5" />
            <line x1="1" y1="12" x2="13" y2="12" stroke="#e2e8f0" stroke-width="1.5" />
            <line x1="1" y1="16" x2="13" y2="16" stroke="#e2e8f0" stroke-width="1.5" />
          </g>

          <!-- 4. KURON BÖLÜMÜ (CROWN) -->
          <g>
            <!-- Molar Crown -->
            <path
              v-if="toothType.startsWith('molar')"
              d="M 6,31 C 5,37 4,55 7,61 C 10,65 15,66 22,66 C 29,66 34,65 37,61 C 40,55 39,37 38,31 C 34,33 28,31 22,33 C 16,31 10,33 6,31 Z"
              :fill="crownFill"
              :stroke="primaryStroke"
              stroke-width="2"
              stroke-linejoin="round"
            />

            <!-- Premolar Crown -->
            <path
              v-else-if="toothType === 'premolar'"
              d="M 8,31 C 7,38 6,54 9,60 C 13,65 17,66 22,66 C 27,66 31,65 35,60 C 38,54 37,38 36,31 C 31,33 27,31 22,33 C 17,31 13,33 8,31 Z"
              :fill="crownFill"
              :stroke="primaryStroke"
              stroke-width="2"
              stroke-linejoin="round"
            />

            <!-- Canine Crown -->
            <path
              v-else-if="toothType === 'canine'"
              d="M 10,31 C 9,39 8,55 12,62 C 16,66 22,67 22,67 C 22,67 28,66 32,62 C 36,55 35,39 34,31 C 29,33 25,31 22,33 C 19,31 15,33 10,31 Z"
              :fill="crownFill"
              :stroke="primaryStroke"
              stroke-width="2"
              stroke-linejoin="round"
            />

            <!-- Incisor Crown -->
            <path
              v-else
              d="M 11,31 C 10,39 9,56 12,62 C 15,65 18,66 22,66 C 26,66 29,65 32,62 C 35,56 34,39 33,31 C 29,33 25,31 22,33 C 19,31 15,33 11,31 Z"
              :fill="crownFill"
              :stroke="primaryStroke"
              stroke-width="2"
              stroke-linejoin="round"
            />
          </g>

          <!-- 5. EŞZAMANLI GÖRSEL KATMANLAR (MULTIPLE OVERLAYS) -->

          <!-- Kaplama / Protez (Crown / Veneer) Katmanı -->
          <path
            v-if="activeProcedures.includes('crown') || activeProcedures.includes('veneer')"
            d="M 7,32 L 37,32 L 35,60 Q 22,66 9,60 Z"
            :fill="`url(#crownGrad-${toothNumber})`"
            stroke="#b45309"
            stroke-width="2"
            opacity="0.9"
          />

          <!-- Dolgu Katmanı (Filled) -->
          <path
            v-if="activeProcedures.includes('filled')"
            d="M 14,40 Q 22,44 30,40 Q 32,54 30,58 Q 22,62 14,58 Z"
            fill="#3b82f6"
            stroke="#1d4ed8"
            stroke-width="1.5"
            opacity="0.85"
          />

          <!-- Çürük Katmanı (Decay) -->
          <circle
            v-if="activeProcedures.includes('decay')"
            cx="22"
            cy="48"
            r="6.5"
            fill="#ef4444"
            stroke="#991b1b"
            stroke-width="1.2"
            class="animate-pulse"
          />

          <!-- Kist / Lezyon Katmanı (Lesion/Cyst) -->
          <circle
            v-if="activeProcedures.includes('lesion_cyst')"
            cx="22"
            cy="8"
            r="8.5"
            fill="#dc2626"
            fill-opacity="0.35"
            stroke="#ef4444"
            stroke-width="1.5"
            stroke-dasharray="2 2"
          />

          <!-- Diş Taşı / Tartar Katmanı (Scaling/Curettage) -->
          <path
            v-if="activeProcedures.includes('scaling') || activeProcedures.includes('curettage')"
            d="M 8,30 Q 22,34 36,30 Q 34,36 8,36 Z"
            fill="#eab308"
            opacity="0.75"
          />

          <!-- Eksik Diş (Missing - Şeffaf Hat) -->
          <g v-if="activeProcedures.includes('missing')">
            <rect x="5" y="5" width="34" height="58" rx="8" fill="none" stroke="#94a3b8" stroke-width="2" stroke-dasharray="3 3" />
          </g>

          <!-- Diş Çekimi (Extraction - Kırmızı Çarpı) -->
          <g v-if="activeProcedures.includes('extraction')" stroke="#ef4444" stroke-width="3.5" stroke-linecap="round">
            <line x1="8" y1="10" x2="36" y2="58" />
            <line x1="36" y1="10" x2="8" y2="58" />
          </g>
        </g>
      </svg>

      <!-- Aktif İşlem Rozetleri (Multi-Procedure Badges) -->
      <div v-if="displayBadges.length > 0" class="absolute -bottom-1 -right-1 flex items-center -space-x-1 z-10">
        <div
          v-for="(badge, idx) in displayBadges"
          :key="idx"
          :class="[
            badge.bg, badge.color,
            'w-4 h-4 rounded-full border border-white dark:border-slate-900 flex items-center justify-center text-[9px] font-bold shadow-md'
          ]"
          :title="badge.label"
        >
          {{ badge.icon }}
        </div>
      </div>
    </div>

    <!-- Diş Numarası Etiketi -->
    <span class="text-[11px] font-bold font-mono text-slate-500 dark:text-slate-400 mt-1 tracking-tight">
      {{ toothNumber }}
    </span>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { useUtils } from '~/composables/useUtils';

const props = defineProps({
  toothNumber: {
    type: Number,
    required: true
  },
  procedures: {
    type: Array,
    default: () => []
  },
  status: {
    type: String,
    default: 'healthy'
  },
  isSelected: {
    type: Boolean,
    default: false
  },
  isUpper: {
    type: Boolean,
    default: true
  },
  width: {
    type: Number,
    default: 38
  },
  height: {
    type: Number,
    default: 58
  }
});

const { getToothStatusInfo } = useUtils();

// Aktif İşlemler Listesi
const activeProcedures = computed(() => {
  if (Array.isArray(props.procedures) && props.procedures.length > 0) {
    return props.procedures;
  }
  if (props.status && props.status !== 'healthy') {
    return [props.status];
  }
  return ['healthy'];
});

// Rozetler
const displayBadges = computed(() => {
  const filtered = activeProcedures.value.filter(p => p !== 'healthy');
  return filtered.slice(0, 3).map(p => getToothStatusInfo(p));
});

// Diş Tipini Belirle
const toothType = computed(() => {
  const lastDigit = props.toothNumber % 10;
  if (lastDigit >= 6) {
    return props.isUpper ? 'molar_upper' : 'molar_lower';
  }
  if (lastDigit >= 4) return 'premolar';
  if (lastDigit === 3) return 'canine';
  return 'incisor';
});

// Kontur Rengi
const primaryStroke = computed(() => {
  if (activeProcedures.value.includes('decay')) return '#dc2626';
  if (activeProcedures.value.includes('rootcanal')) return '#f43f5e';
  if (activeProcedures.value.includes('filled')) return '#2563eb';
  if (activeProcedures.value.includes('crown')) return '#d97706';
  return '#64748b';
});

// Kuron Dolgu Rengi
const crownFill = computed(() => {
  return `url(#toothGrad-${props.toothNumber})`;
});
</script>
