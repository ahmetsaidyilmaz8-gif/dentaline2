export const useAuth = () => {
  const authCookie = useCookie<string | null>('tenax_auth', {
    maxAge: 60 * 60 * 24 * 30, // 30 gün geçerli
    path: '/'
  })

  const isAuthenticated = computed(() => {
    return authCookie.value === 'logged_in'
  })

  const login = (username: string, password: string): { success: boolean; message?: string } => {
    const cleanUsername = username.trim().toLowerCase()
    const cleanPassword = password.trim()

    const validUsernames = ['dt selman', 'dtselman', 'selman', 'dtselo']
    if (validUsernames.includes(cleanUsername) && cleanPassword === '7132') {
      authCookie.value = 'logged_in'
      return { success: true }
    }

    return {
      success: false,
      message: 'Kullanıcı adı veya şifre hatalı!'
    }
  }

  const logout = () => {
    authCookie.value = null
    const router = useRouter()
    router.push('/login')
  }

  return {
    isAuthenticated,
    login,
    logout
  }
}
