<template>
  <div class="flex flex-col gap-8">
    
    <!-- Üst Başlık ve Yeni İş Ekle Butonu -->
    <div class="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <h2 class="text-2xl font-bold text-slate-800 dark:text-white tracking-tight">Laboratuvar & Protez Takip Paneli</h2>
        <p class="text-base text-slate-500 dark:text-slate-400 font-medium">
          Dış laboratuvarlara ve teknisyenlere gönderilen zirkonyum, porselen ve protez işlerinin güncel durumu.
        </p>
      </div>
      <div class="flex items-center gap-2">
        <button
          @click="openNewLabWorkModal"
          class="inline-flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-sm font-bold shadow-md shadow-teal-600/15 active:scale-95 transition-all shadow-sm"
        >
          <Icon name="heroicons:plus-circle" class="w-4 h-4" />
          <span>Yeni Laboratuvar İşi Ekle</span>
        </button>
      </div>
    </div>

    <!-- Özet İstatistik Kartları -->
    <div class="grid grid-cols-1 sm:grid-cols-4 gap-4">
      <!-- Toplam İş -->
      <div
        @click="statusFilter = 'all'"
        :class="[
          'p-5 rounded-2xl shadow-sm flex items-center justify-between cursor-pointer select-none transition-all duration-200 hover:-translate-y-0.5 border',
          statusFilter === 'all'
            ? 'ring-2 ring-slate-400 dark:ring-slate-500 bg-slate-50/80 dark:bg-slate-800/60 border-slate-300 dark:border-slate-600'
            : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800'
        ]"
      >
        <div class="space-y-1">
          <span class="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Toplam İş</span>
          <span class="text-3xl font-black text-slate-800 dark:text-slate-100 font-mono block mt-1 leading-none">
            {{ labWorks.length }}
          </span>
          <span class="text-[11px] text-slate-400 font-semibold block">Tüm kayıtlı teknisyen işleri</span>
        </div>
        <div class="w-12 h-12 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center shrink-0">
          <Icon name="heroicons:cube" class="w-6 h-6" />
        </div>
      </div>

      <!-- Teknisyende -->
      <div
        @click="statusFilter = 'sent'"
        :class="[
          'p-5 rounded-2xl shadow-sm flex items-center justify-between cursor-pointer select-none transition-all duration-200 hover:-translate-y-0.5 border',
          statusFilter === 'sent'
            ? 'ring-2 ring-amber-500 bg-amber-50/50 dark:bg-amber-950/20 border-amber-300 dark:border-amber-700'
            : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800'
        ]"
      >
        <div class="space-y-1">
          <span class="text-xs text-amber-500 font-bold uppercase tracking-wider block">Teknisyende (Bekliyor)</span>
          <span class="text-3xl font-black text-amber-600 dark:text-amber-400 font-mono block mt-1 leading-none">
            {{ countByStatus('sent') }}
          </span>
          <span class="text-[11px] text-slate-400 font-semibold block">Üretim aşamasındaki işler</span>
        </div>
        <div class="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
          <Icon name="heroicons:clock" class="w-6 h-6" />
        </div>
      </div>

      <!-- Kliniğe Ulaştı -->
      <div
        @click="statusFilter = 'received'"
        :class="[
          'p-5 rounded-2xl shadow-sm flex items-center justify-between cursor-pointer select-none transition-all duration-200 hover:-translate-y-0.5 border',
          statusFilter === 'received'
            ? 'ring-2 ring-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-700'
            : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800'
        ]"
      >
        <div class="space-y-1">
          <span class="text-xs text-emerald-500 font-bold uppercase tracking-wider block">Kliniğe Ulaştı (Hazır)</span>
          <span class="text-3xl font-black text-emerald-600 dark:text-emerald-400 font-mono block mt-1 leading-none">
            {{ countByStatus('received') }}
          </span>
          <span class="text-[11px] text-slate-400 font-semibold block">Prova / yapıştırma bekleyen</span>
        </div>
        <div class="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
          <Icon name="heroicons:check-badge" class="w-6 h-6" />
        </div>
      </div>

      <!-- Hastaya Takıldı -->
      <div
        @click="statusFilter = 'fitted'"
        :class="[
          'p-5 rounded-2xl shadow-sm flex items-center justify-between cursor-pointer select-none transition-all duration-200 hover:-translate-y-0.5 border',
          statusFilter === 'fitted'
            ? 'ring-2 ring-sky-500 bg-sky-50/50 dark:bg-sky-950/20 border-sky-300 dark:border-sky-700'
            : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800'
        ]"
      >
        <div class="space-y-1">
          <span class="text-xs text-sky-500 font-bold uppercase tracking-wider block">Hastaya Takıldı</span>
          <span class="text-3xl font-black text-sky-600 dark:text-sky-400 font-mono block mt-1 leading-none">
            {{ countByStatus('fitted') }}
          </span>
          <span class="text-[11px] text-slate-400 font-semibold block">Tamamlanan protez işleri</span>
        </div>
        <div class="w-12 h-12 rounded-xl bg-sky-500/10 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
          <Icon name="heroicons:check" class="w-6 h-6" />
        </div>
      </div>
    </div>

    <!-- Filtre & Arama Çubuğu -->
    <div class="bg-white dark:bg-slate-900 p-4 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
      <div class="relative w-full sm:w-80">
        <Icon name="heroicons:magnifying-glass" class="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          v-model="searchQuery"
          type="text"
          placeholder="Hasta, laboratuvar veya işlem ara..."
          class="w-full pl-10 pr-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-sm focus:outline-none focus:border-teal-500 text-slate-800 dark:text-white"
        />
      </div>

      <div class="flex items-center gap-2 w-full sm:w-auto overflow-x-auto text-xs">
        <button
          v-for="f in filterOptions"
          :key="f.value"
          @click="statusFilter = f.value"
          :class="[
            statusFilter === f.value
              ? 'bg-teal-600 text-white font-bold'
              : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100',
            'px-3.5 py-2 rounded-xl transition-all whitespace-nowrap'
          ]"
        >
          {{ f.label }}
        </button>
      </div>
    </div>

    <!-- Tablo Alanı -->
    <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
      <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse text-sm">
          <thead>
            <tr class="bg-slate-50 dark:bg-slate-950/20 border-b border-slate-100 dark:border-slate-800 text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider text-xs">
              <th class="px-6 py-4">Hasta</th>
              <th class="px-6 py-4">İş Türü & Diş</th>
              <th class="px-6 py-4">Laboratuvar</th>
              <th class="px-6 py-4">Renk</th>
              <th class="px-6 py-4">Tarihler</th>
              <th class="px-6 py-4">Durum</th>
              <th class="px-6 py-4 text-right">Eylemler</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
            <tr v-if="isLoading">
              <td colspan="7" class="px-6 py-12 text-center text-slate-400">
                <Icon name="heroicons:arrow-path" class="w-6 h-6 animate-spin mx-auto mb-2 text-teal-600" />
                <span>Laboratuvar işleri yükleniyor...</span>
              </td>
            </tr>

            <tr v-else-if="filteredLabWorks.length === 0">
              <td colspan="7" class="px-6 py-12 text-center text-slate-400 dark:text-slate-500">
                Eşleşen laboratuvar kaydı bulunamadı.
              </td>
            </tr>

            <tr
              v-for="item in filteredLabWorks"
              :key="item._id"
              class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"
            >
              <!-- Hasta Adı -->
              <td class="px-6 py-4">
                <NuxtLink
                  :to="`/patients/${item.patientId}`"
                  class="font-bold text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-1.5"
                >
                  <Icon name="heroicons:user" class="w-4 h-4 text-slate-400" />
                  <span>{{ item.patientName }}</span>
                </NuxtLink>
              </td>

              <!-- İş Türü & Diş -->
              <td class="px-6 py-4">
                <div class="font-semibold text-slate-800 dark:text-slate-100">
                  {{ item.workType }}
                </div>
                <div v-if="item.toothNumbers && item.toothNumbers.length > 0" class="text-xs font-mono text-teal-600 dark:text-teal-400 mt-0.5">
                  Diş: {{ item.toothNumbers.join(', ') }}
                </div>
              </td>

              <!-- Laboratuvar Adı -->
              <td class="px-6 py-4 font-medium text-slate-700 dark:text-slate-200">
                {{ item.labName }}
              </td>

              <!-- Renk -->
              <td class="px-6 py-4">
                <span class="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 font-mono font-bold text-xs text-slate-700 dark:text-slate-300">
                  {{ item.shadeColor || 'A2' }}
                </span>
              </td>

              <!-- Tarihler -->
              <td class="px-6 py-4 text-xs space-y-0.5">
                <div class="text-slate-400">
                  Gön: {{ formatDate(item.sentDate) }}
                </div>
                <div :class="[isOverdue(item.expectedDate, item.status) ? 'text-rose-600 font-bold' : 'text-slate-700 dark:text-slate-200 font-semibold']">
                  Bek: {{ formatDate(item.expectedDate) }}
                  <span v-if="isOverdue(item.expectedDate, item.status)" class="text-[10px] text-rose-500">(Gecikti)</span>
                </div>
              </td>

              <!-- Durum Rozeti -->
              <td class="px-6 py-4">
                <span
                  :class="[
                    statusConfig[item.status]?.badgeClass || 'bg-slate-100 text-slate-600',
                    'px-2.5 py-1 rounded-full text-xs font-bold inline-block border'
                  ]"
                >
                  {{ statusConfig[item.status]?.label || item.status }}
                </span>
              </td>

              <!-- Hızlı Eylemler -->
              <td class="px-6 py-4 text-right">
                <div class="flex items-center justify-end gap-1.5">
                  <!-- Kliniğe Geldi Butonu -->
                  <button
                    v-if="item.status === 'sent' || item.status === 'revision'"
                    @click="updateStatus(item._id, 'received')"
                    class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-sm"
                    title="Kliniğe Ulaştı Olarak İşaretle"
                  >
                    ✓ Geldi
                  </button>

                  <!-- WhatsApp Bildirimi (Hasta telefonunu bulup tetikle) -->
                  <button
                    v-if="item.status === 'received'"
                    @click="sendWhatsAppToPatient(item)"
                    class="p-1.5 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-lg text-xs font-bold transition-all shadow-sm"
                    title="Hastaya WhatsApp İle Hazır Bildirimi Gönder"
                  >
                    <Icon name="heroicons:chat-bubble-left-right" class="w-4 h-4" />
                  </button>

                  <!-- Takıldı Butonu -->
                  <button
                    v-if="item.status === 'received'"
                    @click="updateStatus(item._id, 'fitted')"
                    class="px-2.5 py-1 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-bold transition-all shadow-sm"
                    title="Hastaya Takıldı"
                  >
                    Takıldı
                  </button>

                  <!-- Sil -->
                  <button
                    @click="deleteLabWork(item._id)"
                    class="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
                    title="Sil"
                  >
                    <Icon name="heroicons:trash" class="w-4 h-4" />
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Yeni Laboratuvar İşi Modalı (Hasta Seçimli) -->
    <AppModal
      :isOpen="isModalOpen"
      title="🔬 Yeni Laboratuvar & Protez İşi Kaydı"
      width="md"
      @close="isModalOpen = false"
    >
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
            Hasta <span class="text-rose-500">*</span>
          </label>
          <select
            v-model="form.patientId"
            required
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          >
            <option value="" disabled>Hasta seçiniz...</option>
            <option v-for="p in patientsList" :key="p._id" :value="p._id">
              {{ p.firstName }} {{ p.lastName }} ({{ p.phone || 'Tel yok' }})
            </option>
          </select>
        </div>

        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
            Teknisyen / Laboratuvar Adı <span class="text-rose-500">*</span>
          </label>
          <input
            v-model="form.labName"
            type="text"
            list="global-lab-suggestions"
            required
            placeholder="Örn: Kumluca Dental Lab"
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
          />
          <datalist id="global-lab-suggestions">
            <option value="Kumluca Dental Lab" />
            <option value="Özlem Diş Protez Lab" />
            <option value="Merkez Dental Laboratuvarı" />
            <option value="Antalya Zirkon & Cad-Cam Lab" />
          </datalist>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
              İş Türü <span class="text-rose-500">*</span>
            </label>
            <input
              v-model="form.workType"
              type="text"
              list="global-worktype-suggestions"
              required
              placeholder="Örn: Zirkonyum Kuron"
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
            <datalist id="global-worktype-suggestions">
              <option value="Zirkonyum Kuron" />
              <option value="E-Max Kuron / Lamina" />
              <option value="Metal Destekli Porselen" />
              <option value="Total Protez" />
              <option value="Bölümlü (İskelet) Protez" />
              <option value="Gece Plağı / Bruksizm" />
              <option value="İmplant Üstü Zirkonyum" />
              <option value="Geçici Kuron" />
            </datalist>
          </div>

          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
              Diş No (Virgülle)
            </label>
            <input
              v-model="form.toothNumbers"
              type="text"
              placeholder="Örn: 11, 21, 22"
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white font-mono"
            />
          </div>
        </div>

        <div class="grid grid-cols-3 gap-3">
          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
              Renk Kodu
            </label>
            <input
              v-model="form.shadeColor"
              type="text"
              placeholder="A2, BL2..."
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white font-mono"
            />
          </div>

          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
              Gönderim Tarihi
            </label>
            <input
              v-model="form.sentDate"
              type="date"
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>

          <div>
            <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
              Beklenen Teslim <span class="text-rose-500">*</span>
            </label>
            <input
              v-model="form.expectedDate"
              type="date"
              required
              class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white"
            />
          </div>
        </div>

        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
            Lab Maliyeti (₺)
          </label>
          <input
            v-model.number="form.price"
            type="number"
            min="0"
            step="50"
            placeholder="0"
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white font-mono"
          />
        </div>

        <div>
          <label class="block text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">
            Teknisyene Notlar
          </label>
          <textarea
            v-model="form.notes"
            rows="2"
            placeholder="Basamak türü, oklüzyon, özel istekler..."
            class="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-teal-500 text-sm bg-white dark:bg-slate-800 text-slate-800 dark:text-white resize-none"
          ></textarea>
        </div>

        <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            @click="isModalOpen = false"
            class="px-4 py-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl text-sm font-bold"
          >
            Vazgeç
          </button>
          <button
            type="button"
            :disabled="isSubmitting"
            @click="saveLabWork"
            class="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-sm font-bold shadow-sm"
          >
            Kaydet
          </button>
        </div>
      </div>
    </AppModal>

  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useUtils } from '~/composables/useUtils';

const { formatDate, todayStr } = useUtils();

const labWorks = ref([]);
const patientsList = ref([]);
const isLoading = ref(true);
const isSubmitting = ref(false);
const isModalOpen = ref(false);
const searchQuery = ref('');
const statusFilter = ref('all');

const form = ref({
  patientId: '',
  labName: 'Kumluca Dental Lab',
  workType: 'Zirkonyum Kuron',
  toothNumbers: '',
  shadeColor: 'A2',
  sentDate: todayStr(),
  expectedDate: '',
  price: 0,
  notes: ''
});

const filterOptions = [
  { value: 'all', label: 'Tüm İşler' },
  { value: 'sent', label: 'Teknisyende' },
  { value: 'received', label: 'Kliniğe Ulaştı' },
  { value: 'fitted', label: 'Hastaya Takıldı' },
  { value: 'revision', label: 'Revizyonda' }
];

const statusConfig = {
  sent: {
    label: 'Teknisyende',
    badgeClass: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20'
  },
  received: {
    label: 'Kliniğe Ulaştı',
    badgeClass: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20'
  },
  fitted: {
    label: 'Hastaya Takıldı',
    badgeClass: 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/20'
  },
  revision: {
    label: 'Revizyonda',
    badgeClass: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20'
  }
};

const countByStatus = (status) => {
  return labWorks.value.filter(w => w.status === status).length;
};

const isOverdue = (expectedDate, status) => {
  if (!expectedDate || status === 'fitted' || status === 'received') return false;
  return new Date(expectedDate) < new Date(new Date().setHours(0, 0, 0, 0));
};

const filteredLabWorks = computed(() => {
  return labWorks.value.filter(item => {
    const matchesStatus = statusFilter.value === 'all' || item.status === statusFilter.value;
    const query = searchQuery.value.toLowerCase().trim();
    if (!query) return matchesStatus;

    const matchesSearch =
      (item.patientName || '').toLowerCase().includes(query) ||
      (item.labName || '').toLowerCase().includes(query) ||
      (item.workType || '').toLowerCase().includes(query) ||
      (item.toothNumbers || []).join(',').includes(query);

    return matchesStatus && matchesSearch;
  });
});

const loadData = async () => {
  try {
    isLoading.value = true;
    const [worksData, patientsData] = await Promise.all([
      $fetch('/api/lab-works'),
      $fetch('/api/patients')
    ]);
    labWorks.value = worksData || [];
    patientsList.value = patientsData || [];
  } catch (error) {
    console.error('Veriler yüklenirken hata:', error);
  } finally {
    isLoading.value = false;
  }
};

const openNewLabWorkModal = () => {
  const d = new Date();
  d.setDate(d.getDate() + 5);
  const fiveDaysLater = d.toISOString().split('T')[0];

  form.value = {
    patientId: patientsList.value.length > 0 ? patientsList.value[0]._id : '',
    labName: 'Kumluca Dental Lab',
    workType: 'Zirkonyum Kuron',
    toothNumbers: '',
    shadeColor: 'A2',
    sentDate: todayStr(),
    expectedDate: fiveDaysLater,
    price: 0,
    notes: ''
  };
  isModalOpen.value = true;
};

const saveLabWork = async () => {
  if (!form.value.patientId || !form.value.labName || !form.value.workType || !form.value.expectedDate) {
    alert('Lütfen tüm zorunlu alanları doldurun.');
    return;
  }

  try {
    isSubmitting.value = true;
    const selectedPatient = patientsList.value.find(p => p._id === form.value.patientId);
    const teeth = form.value.toothNumbers
      ? form.value.toothNumbers.split(',').map(s => s.trim()).filter(Boolean)
      : [];

    await $fetch('/api/lab-works', {
      method: 'POST',
      body: {
        patientId: form.value.patientId,
        patientName: selectedPatient ? `${selectedPatient.firstName} ${selectedPatient.lastName}` : 'Hasta',
        labName: form.value.labName,
        workType: form.value.workType,
        toothNumbers: teeth,
        shadeColor: form.value.shadeColor,
        sentDate: form.value.sentDate,
        expectedDate: form.value.expectedDate,
        price: Number(form.value.price) || 0,
        notes: form.value.notes
      }
    });

    isModalOpen.value = false;
    await loadData();
  } catch (error) {
    console.error(error);
    alert('Laboratuvar işi kaydedilemedi.');
  } finally {
    isSubmitting.value = false;
  }
};

const updateStatus = async (id, status) => {
  try {
    await $fetch(`/api/lab-works/${id}`, {
      method: 'PUT',
      body: { status }
    });
    await loadData();
  } catch (error) {
    console.error(error);
    alert('Durum güncellenirken hata oluştu.');
  }
};

const deleteLabWork = async (id) => {
  if (!confirm('Bu laboratuvar kaydını silmek istediğinize emin misiniz?')) return;
  try {
    await $fetch(`/api/lab-works/${id}`, {
      method: 'DELETE'
    });
    await loadData();
  } catch (error) {
    console.error(error);
    alert('Kayıt silinemedi.');
  }
};

const sendWhatsAppToPatient = (item) => {
  const patient = patientsList.value.find(p => p._id === item.patientId);
  const phone = patient?.phone;
  if (!phone) {
    alert("Hastaya ait telefon numarası bulunamadı.");
    return;
  }

  const teethStr = item.toothNumbers && item.toothNumbers.length > 0 
    ? ` (${item.toothNumbers.join(', ')} no'lu diş)` 
    : '';

  const message = `Sayın ${item.patientName}, laboratuvara gönderilen ${item.workType}${teethStr} işiniz kliniğimize ulaşmıştır. Prova ve yapıştırma seansınız için randevu oluşturmak üzere bize yazabilirsiniz.`;
  
  let cleanPhone = phone.replace(/\D/g, '');
  if (cleanPhone.startsWith('0')) cleanPhone = cleanPhone.substring(1);
  if (!cleanPhone.startsWith('90')) cleanPhone = '90' + cleanPhone;

  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
};

onMounted(() => {
  loadData();
});
</script>
