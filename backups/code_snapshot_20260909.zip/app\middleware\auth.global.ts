export default defineNuxtRouteMiddleware((to) => {
  const authCookie = useCookie<string | null>('tenax_auth')
  const isLoggedIn = authCookie.value === 'logged_in'

  // Giriş yapmamış kullanıcıyı /login sayfasına yönlendir
  if (!isLoggedIn && to.path !== '/login') {
    return navigateTo('/login')
  }

  // Zaten giriş yapmış kullanıcıyı /login yerine ana sayfaya yönlendir
  if (isLoggedIn && to.path === '/login') {
    return navigateTo('/')
  }
})
